# Sietch Unified - Cross-Platform Community Management

A unified backend that bridges Discord and Telegram communities using Collab.Land AccountKit APIs. Built on top of the Arrakis (Sietch) eligibility service and Collab.Land AI Agent Starter Kit.

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         SIETCH UNIFIED                                   │
│                    (The Global Embassy / Brain)                          │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │                    IDENTITY LAYER                                │    │
│  │  ┌─────────────┐   ┌──────────────┐   ┌───────────────────┐    │    │
│  │  │  Discord    │   │  Telegram    │   │   Wallet          │    │    │
│  │  │  OAuth      │   │  Auth        │   │   Verification    │    │    │
│  │  └──────┬──────┘   └──────┬───────┘   └─────────┬─────────┘    │    │
│  │         │                 │                      │              │    │
│  │         └────────────────┼──────────────────────┘              │    │
│  │                          ▼                                      │    │
│  │              ┌─────────────────────┐                           │    │
│  │              │  Collab.Land        │                           │    │
│  │              │  AccountKit         │                           │    │
│  │              │  (Identity Bridge)  │                           │    │
│  │              └──────────┬──────────┘                           │    │
│  └─────────────────────────┼───────────────────────────────────────┘    │
│                            ▼                                            │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │                 CONVICTION LAYER                                 │    │
│  │  ┌─────────────┐   ┌──────────────┐   ┌───────────────────┐    │    │
│  │  │  Dune       │   │  On-Chain    │   │   Custom          │    │    │
│  │  │  Analytics  │   │  Queries     │   │   Oracles         │    │    │
│  │  │  (Black-Box)│   │  (viem)      │   │   (Extensible)    │    │    │
│  │  └──────┬──────┘   └──────┬───────┘   └─────────┬─────────┘    │    │
│  │         │                 │                      │              │    │
│  │         └────────────────┼──────────────────────┘              │    │
│  │                          ▼                                      │    │
│  │              ┌─────────────────────┐                           │    │
│  │              │  Conviction Engine  │                           │    │
│  │              │  (Metric Evaluator) │                           │    │
│  │              └──────────┬──────────┘                           │    │
│  └─────────────────────────┼───────────────────────────────────────┘    │
│                            ▼                                            │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │                   SOCIAL LAYER                                   │    │
│  │  ┌─────────────┐   ┌──────────────┐   ┌───────────────────┐    │    │
│  │  │  Profiles   │   │  Badges      │   │   Directory       │    │    │
│  │  │  (Nyms)     │   │  (10 Types)  │   │   (Searchable)    │    │    │
│  │  └─────────────┘   └──────────────┘   └───────────────────┘    │    │
│  │                                                                  │    │
│  │  ┌─────────────┐   ┌──────────────┐                             │    │
│  │  │  Activity   │   │  Reputation  │                             │    │
│  │  │  (Demurrage)│   │  System      │                             │    │
│  │  └─────────────┘   └──────────────┘                             │    │
│  └──────────────────────────────────────────────────────────────────┘    │
│                                                                          │
├─────────────────────────────────────────────────────────────────────────┤
│                    PLATFORM LIMBS                                        │
│  ┌─────────────────────┐              ┌─────────────────────┐           │
│  │     DISCORD         │              │     TELEGRAM        │           │
│  │  ┌───────────────┐  │              │  ┌───────────────┐  │           │
│  │  │ discord.js    │  │              │  │ grammy        │  │           │
│  │  │ Bot           │  │              │  │ Bot           │  │           │
│  │  └───────────────┘  │              │  └───────────────┘  │           │
│  │  ┌───────────────┐  │              │  ┌───────────────┐  │           │
│  │  │ Role Manager  │  │              │  │ Mini App      │  │           │
│  │  │ (Stillsuits)  │  │              │  │ (@twa-dev/sdk)│  │           │
│  │  └───────────────┘  │              │  └───────────────┘  │           │
│  └─────────────────────┘              └─────────────────────┘           │
├─────────────────────────────────────────────────────────────────────────┤
│                    PERSISTENCE & AUTOMATION                              │
│  ┌─────────────────────┐              ┌─────────────────────┐           │
│  │     PostgreSQL      │              │       Redis         │           │
│  │  (Identity Mapping) │              │  (Session Cache)    │           │
│  └─────────────────────┘              └─────────────────────┘           │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │                    trigger.dev                                   │    │
│  │  ┌─────────────┐  ┌──────────────┐  ┌───────────────────┐       │    │
│  │  │ Activity    │  │ Eligibility  │  │ Badge             │       │    │
│  │  │ Decay (6hr) │  │ Re-verify    │  │ Evaluation        │       │    │
│  │  └─────────────┘  └──────────────┘  └───────────────────┘       │    │
│  └─────────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────┘
```

## Directory Structure

```
sietch-unified/
├── packages/
│   ├── server/                 # Express.js Command Center
│   │   ├── src/
│   │   │   ├── config/        # Environment & conviction configs
│   │   │   ├── controllers/   # Route handlers
│   │   │   ├── services/      # Business logic
│   │   │   │   ├── identity/  # Cross-platform identity bridging
│   │   │   │   ├── conviction/# Metric evaluation engine
│   │   │   │   ├── social/    # Profiles, badges, directory
│   │   │   │   └── platform/  # Discord/Telegram adapters
│   │   │   ├── middleware/    # Auth, validation, rate limiting
│   │   │   ├── routes/        # API endpoints
│   │   │   ├── models/        # Database models (Prisma)
│   │   │   ├── jobs/          # trigger.dev scheduled tasks
│   │   │   └── types/         # TypeScript definitions
│   │   └── prisma/
│   │       └── schema.prisma  # Database schema
│   │
│   ├── discord-bot/           # Discord.js bot
│   │   ├── src/
│   │   │   ├── commands/      # Slash commands
│   │   │   ├── events/        # Event handlers
│   │   │   ├── services/      # Role management, stillsuits
│   │   │   └── utils/
│   │   └── package.json
│   │
│   ├── telegram-bot/          # Telegram bot (grammy)
│   │   ├── src/
│   │   │   ├── commands/      # Bot commands
│   │   │   ├── handlers/      # Message handlers
│   │   │   └── middleware/    # Telegram-specific middleware
│   │   └── package.json
│   │
│   ├── telegram-miniapp/      # Telegram Mini App (React + TWA)
│   │   ├── src/
│   │   │   ├── components/    # React components
│   │   │   ├── pages/         # Directory, Profile, Settings
│   │   │   ├── hooks/         # Custom hooks
│   │   │   └── lib/           # TWA SDK integration
│   │   └── package.json
│   │
│   └── shared/                # Shared types and utilities
│       ├── src/
│       │   ├── types/         # Shared TypeScript types
│       │   ├── constants/     # Shared constants
│       │   └── utils/         # Shared utilities
│       └── package.json
│
├── config/
│   ├── conviction-metrics.yaml  # Server owner configurations
│   └── roles.yaml               # Role definitions
│
├── docker-compose.yml           # PostgreSQL, Redis
├── package.json                 # Workspace root
├── pnpm-workspace.yaml
├── tsconfig.base.json
└── README.md
```

## Core Concepts

### 1. Global Identity (The Diplomatic Passport)
Using Collab.Land AccountKit, we bridge Discord UIDs and Telegram UIDs to a single verified wallet address.

### 2. Conviction Metrics
Server owners define what "conviction" means for their community via YAML configuration. The engine evaluates users against these metrics using Dune Analytics as a black-box API.

### 3. The Handshake Workflow
When a user verifies on one platform, they automatically receive corresponding roles on the other platform.

### 4. Demurrage Activity Model
Activity scores decay by 10% every 6 hours, rewarding consistent engagement over one-time bursts.

## Quick Start

```bash
# Clone and install
git clone https://github.com/0xHoneyJar/sietch-unified
cd sietch-unified
pnpm install

# Set up environment
cp .env.example .env
# Edit .env with your credentials

# Start infrastructure
docker-compose up -d

# Run migrations
pnpm db:migrate

# Start development servers
pnpm dev
```

## Environment Variables

See `.env.example` for full list. Key variables:

```bash
# Collab.Land
COLLABLAND_API_KEY=your_api_key

# Database
DATABASE_URL=postgresql://...
REDIS_URL=redis://...

# Discord
DISCORD_BOT_TOKEN=...
DISCORD_CLIENT_ID=...
DISCORD_CLIENT_SECRET=...

# Telegram
TELEGRAM_BOT_TOKEN=...

# Dune Analytics
DUNE_API_KEY=...

# trigger.dev
TRIGGER_API_KEY=...
```

## API Reference

### Identity Endpoints
- `POST /api/identity/link` - Link social account to wallet
- `GET /api/identity/:walletAddress` - Get linked accounts
- `POST /api/identity/verify` - Initiate verification handshake

### Conviction Endpoints
- `GET /api/conviction/:walletAddress` - Get conviction status
- `POST /api/conviction/evaluate` - Force re-evaluation

### Social Endpoints
- `GET /api/directory` - Browse member directory
- `GET /api/profile/:identifier` - Get user profile
- `PUT /api/profile` - Update profile
- `GET /api/badges/:identifier` - Get user badges

### Admin Endpoints (API Key Required)
- `POST /admin/sync` - Trigger full sync
- `POST /admin/decay` - Apply activity decay
- `POST /admin/badges/check` - Run badge evaluation

## License

MIT
