# Sietch Unified - Enterprise Architecture Report v2.1

## Executive Summary

**Sietch Unified** is an enterprise-grade cross-platform community management system that bridges Discord and Telegram communities using Collab.Land AccountKit APIs. This version implements the full enterprise standards framework aligned with Microsoft, Google, and AWS best practices, **including subscription billing and feature gating**.

**Total Lines of Code:** 14,500+  
**Number of Files:** 62  
**Architecture:** TypeScript monorepo with Three-Zone managed scaffolding

---

## Enterprise Standards Compliance

| Standard | Implementation | Status |
|----------|----------------|--------|
| **AWS - Three-Zone Architecture** | System/State/App zones with Loa framework | ✅ Implemented |
| **AWS - Immutable System Zones** | SHA-256 checksums with anti-tamper detection | ✅ Implemented |
| **Microsoft - Unified Identity** | Collab.Land AccountKit integration | ✅ Implemented |
| **Microsoft - Credential Protection** | 1Password + GCP Secret Manager integration | ✅ Implemented |
| **Google - Serverless Execution** | Cloud Run with VPC connector | ✅ Implemented |
| **Google - Infrastructure as Code** | Terraform for GCP deployment | ✅ Implemented |
| **SRE - Operational Excellence** | 24hr grace period, scheduled tasks | ✅ Implemented |
| **GDPR - Data Residency** | Regional deployment configuration | ✅ Implemented |
| **Quality Gates** | Tech Lead + Security Audit workflows | ✅ Implemented |
| **Documentation** | PRD + SDD in State Zone | ✅ Implemented |
| **Subscription Billing** | Stripe integration with Gatekeeper service | ✅ Implemented |
| **Feature Gating** | Tier-based access control aligned with Collab.Land | ✅ Implemented |

---

## Complete File Tree

```
sietch-unified/
├── .env.example                                    # Environment template
├── .gitignore                                      # Git exclusions
├── loa.yaml                                        # Loa framework manifest (201 lines)
├── Makefile                                        # Developer commands (116 lines)
├── package.json                                    # Root workspace config
├── pnpm-workspace.yaml                             # pnpm monorepo config
├── tsconfig.json                                   # Base TypeScript config
├── turbo.json                                      # Turborepo pipeline
├── README.md                                       # Project documentation (237 lines)
├── ARCHITECTURE_REPORT.md                          # This report
├── docker-compose.yml                              # Local development (84 lines)
│
├── .github/
│   ├── CODEOWNERS                                 # Review requirements
│   ├── BRANCH_PROTECTION.md                       # GitHub settings guide
│   └── workflows/
│       ├── ci-cd.yml                              # CI/CD pipeline (311 lines)
│       └── quality-gates.yml                      # Quality gates (280 lines)
│
├── system/                                         # SYSTEM ZONE (Immutable)
│   └── core/
│       ├── integrity.ts                           # Anti-tamper system (538 lines)
│       └── framework.ts                           # Loa framework core (545 lines)
│
├── state/                                          # STATE ZONE (Preserved)
│   ├── grimoire.yaml                              # Project memory (97 lines)
│   ├── PRD.md                                     # Product Requirements (480 lines)
│   └── SDD.md                                     # Software Design Doc (850 lines)
│
├── config/
│   ├── conviction-metrics.yaml                    # Conviction rules (241 lines)
│   ├── subscription-tiers.yaml                    # Billing tiers (220 lines)
│   └── data-residency.yaml                        # GDPR config (280 lines) [NEW]
│
├── docs/
│   ├── security/
│   │   └── HARDENING_GUIDE.md                     # Security guide (416 lines)
│   └── legal/
│       └── DPA_TEMPLATE.md                        # GDPR DPA template (350 lines) [NEW]
│
├── scripts/
│   └── setup.sh                                   # First-time setup (137 lines)
│
├── docs/
│   └── security/
│       └── HARDENING_GUIDE.md                     # Security guide (416 lines)
│
├── infrastructure/
│   └── terraform/
│       ├── main.tf                                # GCP infrastructure (760 lines)
│       ├── variables.tf                           # Terraform variables (165 lines)
│       ├── outputs.tf                             # Terraform outputs (145 lines)
│       └── terraform.tfvars.example               # Variables template
│
└── packages/
    ├── server/                                     # Hono API (4,200+ lines) [UPDATED]
    │   ├── package.json
    │   ├── tsconfig.json
    │   ├── Dockerfile                             # Production container (97 lines)
    │   ├── prisma/
    │   │   └── schema.prisma                      # Database schema (600 lines) [UPDATED]
    │   └── src/
    │       ├── index.ts                           # Hono server entry (290 lines)
    │       ├── routes/
    │       │   ├── identity.routes.ts             # Identity endpoints (180 lines)
    │       │   ├── conviction.routes.ts           # Scoring endpoints (200 lines)
    │       │   ├── profile.routes.ts              # Profile endpoints (220 lines)
    │       │   ├── directory.routes.ts            # Directory endpoints (180 lines)
    │       │   ├── billing.routes.ts              # Billing endpoints (280 lines)
    │       │   ├── badge.routes.ts                # Score badge endpoints (260 lines)
    │       │   ├── boost.routes.ts                # Community boost endpoints (300 lines) [NEW]
    │       │   ├── gdpr.routes.ts                 # GDPR data rights (380 lines)
    │       │   ├── admin.routes.ts                # Admin + waiver endpoints (520 lines)
    │       │   └── webhook.routes.ts              # Webhook endpoints (80 lines)
    │       ├── jobs/
    │       │   └── scheduled-tasks.ts             # trigger.dev jobs (490 lines)
    │       └── services/
    │           ├── identity/
    │           │   └── identity-bridge.service.ts # Identity bridging (280 lines)
    │           ├── conviction/
    │           │   └── conviction-engine.service.ts # Metrics engine (420 lines)
    │           ├── collabland/
    │           │   └── collabland-client.service.ts # AccountKit (160 lines)
    │           ├── theme/
    │           │   └── theme-engine.service.ts     # White-label branding (320 lines) [NEW v2.4]
    │           ├── rules/
    │           │   └── rules-engine.service.ts     # Token-gating rules (450 lines) [NEW v2.4]
    │           ├── observability/
    │           │   └── observability.service.ts    # OpenTelemetry (380 lines) [NEW v2.4]
    │           ├── compliance/
    │           │   └── data-lifecycle.service.ts   # PII auto-purge (350 lines) [NEW v2.4]
    │           └── billing/
    │               ├── gatekeeper.service.ts       # Feature gating + waivers (920 lines)
    │               ├── badge.service.ts            # Score badge logic (450 lines)
    │               ├── boost.service.ts            # Community boost logic (520 lines)
    │               ├── idempotent-webhook.service.ts # Idempotent webhooks (320 lines) [NEW v2.4]
    │               └── stripe-webhook.service.ts   # Webhook handler (350 lines)
    │
    ├── discord-bot/                                # Discord.js v14 (1,182 lines)
    │   ├── package.json
    │   ├── tsconfig.json
    │   ├── Dockerfile                             # Production container (67 lines)
    │   └── src/
    │       ├── index.ts                           # Bot + commands (695 lines)
    │       └── services/
    │           └── role-manager.service.ts        # Role management (420 lines)
    │
    ├── telegram-bot/                               # grammy bot (511 lines)
    │   ├── package.json
    │   ├── tsconfig.json
    │   ├── Dockerfile                             # Production container (67 lines)
    │   └── src/
    │       └── index.ts                           # Bot + commands (444 lines)
    │
    ├── telegram-miniapp/                           # React + TWA (358 lines)
    │   ├── package.json
    │   ├── tsconfig.json
    │   ├── tsconfig.node.json
    │   ├── vite.config.ts                         # Vite config (21 lines)
    │   ├── index.html
    │   └── src/
    │       └── App.tsx                            # Mini App UI (337 lines)
    │
    └── shared/                                     # Shared types (508 lines)
        ├── package.json
        ├── tsconfig.json
        └── src/
            ├── index.ts                           # Re-exports (5 lines)
            ├── types/
            │   └── index.ts                       # TypeScript types (417 lines)
            └── utils/
                └── index.ts                       # Utility functions (86 lines)
```

---

## Three-Zone Architecture (Loa Framework)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           LOA FRAMEWORK                                      │
│                    "The Loa mounts and rides the host"                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                    SYSTEM ZONE (Immutable)                           │   │
│   │                                                                      │   │
│   │   • Overwritten on framework updates                                 │   │
│   │   • SHA-256 checksums for integrity verification                     │   │
│   │   • Protected files trigger CI failures if modified                  │   │
│   │                                                                      │   │
│   │   Files:                                                             │   │
│   │   ├── system/core/integrity.ts                                      │   │
│   │   ├── system/core/framework.ts                                      │   │
│   │   ├── packages/server/src/services/**/*                             │   │
│   │   ├── packages/shared/src/**/*                                      │   │
│   │   └── infrastructure/terraform/modules/**/*                         │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                    STATE ZONE (Preserved)                            │   │
│   │                                                                      │   │
│   │   • Preserved across framework updates                               │   │
│   │   • Automatic backup before updates                                  │   │
│   │   • Contains project-specific configuration                          │   │
│   │                                                                      │   │
│   │   Files:                                                             │   │
│   │   ├── state/grimoire.yaml (project memory)                          │   │
│   │   ├── state/checksums.json (integrity manifest)                     │   │
│   │   ├── config/conviction-metrics.yaml                                │   │
│   │   └── prisma/migrations/**/*                                        │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                    APP ZONE (Developer Owned)                        │   │
│   │                                                                      │   │
│   │   • Never touched by framework                                       │   │
│   │   • Full developer ownership                                         │   │
│   │   • Custom extensions and integrations                               │   │
│   │                                                                      │   │
│   │   Files:                                                             │   │
│   │   ├── app/**/*                                                      │   │
│   │   ├── packages/*/src/custom/**/*                                    │   │
│   │   └── scripts/custom/**/*                                           │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Integrity Verification System

### How It Works

1. **Checksum Generation** - SHA-256 hashes computed for all system zone files
2. **Manifest Storage** - Checksums stored in `state/checksums.json`
3. **Verification** - Compares current files against stored hashes
4. **Violation Detection** - Identifies modified, deleted, or added files
5. **CI Integration** - Build fails on integrity violations

### Commands

```bash
# Generate checksums for system zone
npm run integrity:generate

# Verify integrity (runs automatically on build)
npm run integrity:verify

# Full integrity report
npm run integrity:report

# Check specific file zone
npm run loa:check packages/server/src/services/identity/identity-bridge.service.ts
```

### Severity Levels

| Severity | Description | CI Impact |
|----------|-------------|-----------|
| **Critical** | Protected system file modified | Build fails |
| **High** | System zone file modified | Build fails |
| **Medium** | State zone unexpected change | Warning |
| **Low** | App zone change | Logged only |

---

## Infrastructure as Code (Terraform)

### GCP Resources Provisioned

| Resource | Service | Purpose |
|----------|---------|---------|
| VPC Network | Compute | Private networking |
| VPC Connector | Serverless | Cloud Run to private services |
| Cloud SQL | PostgreSQL 16 | Primary database |
| Memorystore | Redis 7 | Session cache |
| Secret Manager | 7 secrets | Credential storage |
| Cloud Run | 3 services | API, Discord bot, Telegram bot |
| Artifact Registry | Docker | Container images |
| Cloud Scheduler | 3 jobs | Scheduled tasks |
| Cloud Armor | WAF | Security (optional) |
| Monitoring | Uptime + Alerts | Observability |

### Deployment

```bash
cd infrastructure/terraform

# Initialize
terraform init

# Plan
terraform plan -var-file=terraform.tfvars

# Apply
terraform apply -var-file=terraform.tfvars
```

### GDPR Data Residency

```hcl
# terraform.tfvars
data_region = "eu"  # Options: us, eu, asia

# Automatically maps to:
# - us   → us-central1
# - eu   → europe-west1
# - asia → asia-southeast1
```

---

## Secrets Management

### 1Password Integration

```bash
# Store secrets
op item create --category="API Credential" --title="Collab.Land API" \
  --vault="Sietch-Unified" api_key="your-key"

# Load secrets to .env
op inject -i .env.1password -o .env

# Use in scripts
export COLLABLAND_API_KEY=$(op read "op://Sietch-Unified/Collab.Land API/api_key")
```

### GCP Secret Manager

Secrets are automatically created by Terraform and injected into Cloud Run services:

- `sietch-unified-database-url`
- `sietch-unified-redis-url`
- `sietch-unified-collabland-api-key`
- `sietch-unified-dune-api-key`
- `sietch-unified-discord-bot-token`
- `sietch-unified-telegram-bot-token`
- `sietch-unified-admin-api-key`

---

## CI/CD Pipeline

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                            CI/CD PIPELINE                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│   ┌──────────────┐    ┌──────────────┐    ┌──────────────┐                  │
│   │  INTEGRITY   │───▶│    LINT &    │───▶│    BUILD     │                  │
│   │    CHECK     │    │  TYPE CHECK  │    │              │                  │
│   └──────────────┘    └──────────────┘    └──────────────┘                  │
│          │                                       │                           │
│          │ Fail on                               │                           │
│          │ violations                            ▼                           │
│          │                              ┌──────────────┐                     │
│          │                              │     TEST     │                     │
│          │                              │   (with DB)  │                     │
│          │                              └──────────────┘                     │
│          │                                       │                           │
│          │                     ┌─────────────────┴─────────────────┐        │
│          │                     │                                   │        │
│          │               develop branch                      main branch    │
│          │                     ▼                                   ▼        │
│          │            ┌──────────────┐                    ┌──────────────┐  │
│          │            │   STAGING    │                    │  PRODUCTION  │  │
│          │            │   DEPLOY     │                    │    DEPLOY    │  │
│          │            └──────────────┘                    └──────────────┘  │
│          │                                                        │        │
│          │                                                        ▼        │
│          │                                               ┌──────────────┐  │
│          └──────────────────────────────────────────────▶│  REGENERATE  │  │
│                              Update checksums            │  CHECKSUMS   │  │
│                              after deploy                └──────────────┘  │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Quality Gates Workflow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         QUALITY GATES                                        │
│                   Two-Gate Approval Process                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                    GATE 1: AUTOMATED CHECKS                          │   │
│   │                                                                      │   │
│   │   ┌─────────────┐  ┌─────────────┐  ┌─────────────┐                 │   │
│   │   │  Integrity  │  │    Type     │  │  Security   │                 │   │
│   │   │   Verify    │  │   Check     │  │    Scan     │                 │   │
│   │   └──────┬──────┘  └──────┬──────┘  └──────┬──────┘                 │   │
│   │          │                │                │                         │   │
│   │          └────────────────┼────────────────┘                         │   │
│   │                           ▼                                          │   │
│   │                    All Must Pass                                     │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                               │                                              │
│                               ▼                                              │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                    GATE 2: TECH LEAD REVIEW                          │   │
│   │                                                                      │   │
│   │   • Code review by senior engineer                                   │   │
│   │   • Architecture validation                                          │   │
│   │   • Performance review                                               │   │
│   │   • Label: needs-tech-lead-review                                    │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                               │                                              │
│                               ▼                                              │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                    GATE 3: SECURITY AUDIT                            │   │
│   │                                                                      │   │
│   │   Triggered when security-sensitive files changed:                   │   │
│   │   • system/core/*                                                    │   │
│   │   • infrastructure/terraform/*                                       │   │
│   │   • .github/workflows/*                                              │   │
│   │   • packages/server/src/services/identity/*                          │   │
│   │   • packages/server/src/routes/*                                     │   │
│   │   • prisma/schema.prisma                                             │   │
│   │                                                                      │   │
│   │   Label: needs-security-audit                                        │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                               │                                              │
│                               ▼                                              │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                    ✅ READY TO MERGE                                 │   │
│   │                                                                      │   │
│   │   All gates passed → Label: quality-gates-passed                     │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Gate Requirements

| Gate | Approvers | Trigger |
|------|-----------|---------|
| Automated Checks | CI/CD | All PRs |
| Tech Lead Review | `@tech-leads` team | All PRs |
| Security Audit | `@security-auditors` team | Security-sensitive files |

### CODEOWNERS Enforcement

The `CODEOWNERS` file automatically requests reviews from appropriate teams based on which files are changed.

---

## Lines of Code by Category

| Category | Files | Lines | Percentage |
|----------|-------|-------|------------|
| **Server (API)** | 7 | 3,434 | 27.8% |
| **Documentation (PRD/SDD)** | 2 | 1,330 | 10.8% |
| **Discord Bot** | 3 | 1,182 | 9.6% |
| **Loa Framework** | 3 | 1,284 | 10.4% |
| **Infrastructure (Terraform)** | 4 | 1,070 | 8.7% |
| **CI/CD & Quality Gates** | 4 | 720 | 5.8% |
| **Telegram Bot** | 2 | 511 | 4.1% |
| **Shared Types/Utils** | 3 | 508 | 4.1% |
| **Security Docs** | 2 | 510 | 4.1% |
| **Configuration** | 6 | 640 | 5.2% |
| **Telegram Mini App** | 2 | 358 | 2.9% |
| **Other (Docker, Scripts)** | 6 | 785 | 6.4% |
| **Total** | **57** | **12,332** | **100%** |

---

## New Commands Reference

### Framework Management
```bash
npm run loa:status          # Show framework status
npm run loa:backup          # Create state backup
npm run loa:backups         # List available backups
npm run loa:restore <dir>   # Restore from backup
npm run loa:check <file>    # Check file zone
```

### Integrity Operations
```bash
npm run integrity:generate  # Generate checksums
npm run integrity:verify    # Verify system zone
npm run integrity:verify:all # Verify all zones
npm run integrity:report    # Full report
```

### Secrets
```bash
npm run secrets:load        # Load from 1Password
```

### Update Workflow
```bash
npm run preupdate           # Verify + backup (pre-hook)
npm run postupdate          # Generate + build (post-hook)
```

---

## Security Checklist

- [x] Three-zone architecture prevents accidental system modifications
- [x] SHA-256 integrity checksums with CI enforcement
- [x] 1Password integration for local development
- [x] GCP Secret Manager for production
- [x] VPC-only database access (no public IP)
- [x] Cloud Armor WAF (optional)
- [x] Rate limiting (100 req/min)
- [x] Telegram signature verification (HMAC-SHA256)
- [x] Admin API key authentication
- [x] Non-root Docker containers
- [x] GDPR data residency configuration

---

## Deployment Checklist

### Pre-Production
- [ ] Run `npm run integrity:generate` to create initial checksums
- [ ] Store all secrets in 1Password vault "Sietch-Unified"
- [ ] Configure `terraform.tfvars` with project details
- [ ] Run `terraform apply` to provision infrastructure
- [ ] Set secret values in GCP Secret Manager
- [ ] Build and push Docker images
- [ ] Run database migrations
- [ ] Set Telegram webhook URL
- [ ] Verify all services healthy

### Post-Deployment
- [ ] Verify integrity checks pass in CI
- [ ] Test all API endpoints
- [ ] Test Discord commands
- [ ] Test Telegram commands and Mini App
- [ ] Verify scheduled tasks run
- [ ] Set up alerting channels

---

## Quick Start

```bash
# Clone repository
git clone https://github.com/0xHoneyJar/sietch-unified
cd sietch-unified

# First-time setup
make setup

# Load secrets from 1Password
npm run secrets:load

# Start development
make dev

# Or deploy to GCP
cd infrastructure/terraform
terraform init
terraform apply
```

---

*Report generated: December 25, 2024*  
*Framework version: 1.0.0*  
*Enterprise standards: AWS + Microsoft + Google aligned*  
*Quality gates: Tech Lead + Security Audit enforced*
