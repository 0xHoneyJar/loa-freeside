# Security Hardening Guide

## Overview

This guide covers security best practices for deploying Sietch Unified in production, aligned with Microsoft, Google, and AWS security standards.

## Table of Contents

1. [Secrets Management](#secrets-management)
2. [1Password Integration](#1password-integration)
3. [GCP Secret Manager](#gcp-secret-manager)
4. [API Key Rotation](#api-key-rotation)
5. [Network Security](#network-security)
6. [Authentication & Authorization](#authentication--authorization)
7. [Compliance Checklist](#compliance-checklist)

---

## Secrets Management

### Golden Rules

1. **Never commit secrets to version control** - Use `.gitignore` to exclude `.env`, `*.pem`, `*.key`
2. **Use vault-based secret management** - 1Password, HashiCorp Vault, or cloud provider secrets
3. **Rotate secrets regularly** - Minimum 90 days for API keys
4. **Audit secret access** - Enable logging for all secret operations

### Secret Categories

| Category | Examples | Rotation Frequency |
|----------|----------|-------------------|
| Critical | Database passwords, JWT signing keys | 30 days |
| High | Bot tokens, API keys | 90 days |
| Medium | Webhook URLs, non-sensitive config | 180 days |

---

## 1Password Integration

### Setup

1. **Install 1Password CLI**
   ```bash
   # macOS
   brew install 1password-cli

   # Linux
   curl -sS https://downloads.1password.com/linux/keys/1password.asc | \
     sudo gpg --dearmor --output /usr/share/keyrings/1password-archive-keyring.gpg
   echo "deb [arch=amd64 signed-by=/usr/share/keyrings/1password-archive-keyring.gpg] https://downloads.1password.com/linux/debian/amd64 stable main" | \
     sudo tee /etc/apt/sources.list.d/1password.list
   sudo apt update && sudo apt install 1password-cli
   ```

2. **Sign in to 1Password**
   ```bash
   eval $(op signin)
   ```

3. **Create a vault for Sietch**
   ```bash
   op vault create "Sietch-Unified"
   ```

### Store Secrets

```bash
# Create items for each secret
op item create \
  --category="API Credential" \
  --title="Collab.Land API" \
  --vault="Sietch-Unified" \
  api_key="your-collabland-api-key"

op item create \
  --category="API Credential" \
  --title="Dune Analytics" \
  --vault="Sietch-Unified" \
  api_key="your-dune-api-key"

op item create \
  --category="API Credential" \
  --title="Discord Bot" \
  --vault="Sietch-Unified" \
  token="your-discord-bot-token" \
  client_id="your-client-id" \
  client_secret="your-client-secret"

op item create \
  --category="API Credential" \
  --title="Telegram Bot" \
  --vault="Sietch-Unified" \
  token="your-telegram-bot-token"
```

### Retrieve Secrets in Scripts

```bash
#!/bin/bash
# scripts/load-secrets.sh

# Load secrets from 1Password
export COLLABLAND_API_KEY=$(op read "op://Sietch-Unified/Collab.Land API/api_key")
export DUNE_API_KEY=$(op read "op://Sietch-Unified/Dune Analytics/api_key")
export DISCORD_BOT_TOKEN=$(op read "op://Sietch-Unified/Discord Bot/token")
export TELEGRAM_BOT_TOKEN=$(op read "op://Sietch-Unified/Telegram Bot/token")

echo "✅ Secrets loaded from 1Password"
```

### Environment Template with 1Password References

Create `.env.1password`:

```bash
# =============================================================================
# 1PASSWORD SECRET REFERENCES
# =============================================================================
# Use: eval $(op inject -i .env.1password -o .env)

DATABASE_URL=op://Sietch-Unified/Database/connection_string
REDIS_URL=op://Sietch-Unified/Redis/url

COLLABLAND_API_KEY=op://Sietch-Unified/Collab.Land API/api_key
DUNE_API_KEY=op://Sietch-Unified/Dune Analytics/api_key

DISCORD_BOT_TOKEN=op://Sietch-Unified/Discord Bot/token
DISCORD_CLIENT_ID=op://Sietch-Unified/Discord Bot/client_id
DISCORD_CLIENT_SECRET=op://Sietch-Unified/Discord Bot/client_secret

TELEGRAM_BOT_TOKEN=op://Sietch-Unified/Telegram Bot/token

ADMIN_API_KEY=op://Sietch-Unified/Admin/api_key
```

Inject secrets:

```bash
op inject -i .env.1password -o .env
```

### CI/CD Integration

**GitHub Actions with 1Password:**

```yaml
# .github/workflows/deploy.yml
name: Deploy

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Load secrets from 1Password
        uses: 1password/load-secrets-action@v1
        with:
          export-env: true
        env:
          OP_SERVICE_ACCOUNT_TOKEN: ${{ secrets.OP_SERVICE_ACCOUNT_TOKEN }}
          COLLABLAND_API_KEY: op://Sietch-Unified/Collab.Land API/api_key
          DUNE_API_KEY: op://Sietch-Unified/Dune Analytics/api_key
          DISCORD_BOT_TOKEN: op://Sietch-Unified/Discord Bot/token
          TELEGRAM_BOT_TOKEN: op://Sietch-Unified/Telegram Bot/token

      - name: Deploy to Cloud Run
        run: |
          gcloud run deploy sietch-unified-api \
            --set-env-vars="COLLABLAND_API_KEY=$COLLABLAND_API_KEY"
```

---

## GCP Secret Manager

### Create Secrets

```bash
# Enable Secret Manager API
gcloud services enable secretmanager.googleapis.com

# Create secrets
echo -n "your-collabland-api-key" | \
  gcloud secrets create sietch-collabland-api-key --data-file=-

echo -n "your-dune-api-key" | \
  gcloud secrets create sietch-dune-api-key --data-file=-

echo -n "your-discord-bot-token" | \
  gcloud secrets create sietch-discord-bot-token --data-file=-

echo -n "your-telegram-bot-token" | \
  gcloud secrets create sietch-telegram-bot-token --data-file=-
```

### Grant Access

```bash
# Grant Cloud Run service account access
gcloud secrets add-iam-policy-binding sietch-collabland-api-key \
  --member="serviceAccount:sietch-unified-cloud-run@YOUR_PROJECT.iam.gserviceaccount.com" \
  --role="roles/secretmanager.secretAccessor"
```

### Access in Cloud Run

Secrets are automatically injected as environment variables when configured in Terraform (see `main.tf`).

---

## API Key Rotation

### Rotation Procedure

1. **Generate new key** in the provider's dashboard
2. **Add new key** to Secret Manager as new version
3. **Update Cloud Run** to use new version
4. **Verify** application works with new key
5. **Disable old key** in provider's dashboard
6. **Delete old version** from Secret Manager (after 7 days)

### Automated Rotation Script

```bash
#!/bin/bash
# scripts/rotate-api-key.sh

SECRET_NAME=$1
NEW_VALUE=$2

if [ -z "$SECRET_NAME" ] || [ -z "$NEW_VALUE" ]; then
  echo "Usage: ./rotate-api-key.sh <secret-name> <new-value>"
  exit 1
fi

# Add new version
echo -n "$NEW_VALUE" | gcloud secrets versions add $SECRET_NAME --data-file=-

# Get new version number
NEW_VERSION=$(gcloud secrets versions list $SECRET_NAME --format='value(name)' --limit=1)

echo "✅ Created new version: $NEW_VERSION"
echo "⚠️  Remember to:"
echo "   1. Update Cloud Run to use new version"
echo "   2. Verify application works"
echo "   3. Disable old key in provider dashboard"
echo "   4. Delete old version after 7 days"
```

---

## Network Security

### VPC Configuration

- All Cloud Run services use VPC connector for private access
- Cloud SQL and Redis are only accessible via private IP
- No public IPs exposed for database services

### Firewall Rules

```bash
# Allow Cloud Run to access Cloud SQL
gcloud compute firewall-rules create allow-cloud-run-to-sql \
  --network=sietch-unified-vpc \
  --allow=tcp:5432 \
  --source-ranges=10.8.0.0/28 \
  --target-tags=cloud-sql

# Allow Cloud Run to access Redis
gcloud compute firewall-rules create allow-cloud-run-to-redis \
  --network=sietch-unified-vpc \
  --allow=tcp:6379 \
  --source-ranges=10.8.0.0/28 \
  --target-tags=redis
```

### Cloud Armor (WAF)

Enable Cloud Armor for production:

```hcl
# In terraform.tfvars
enable_cloud_armor = true
```

Protects against:
- SQL injection
- XSS attacks
- Rate limiting (100 req/min per IP)
- Known bad actors

---

## Authentication & Authorization

### API Authentication

| Endpoint | Auth Method | Rate Limit |
|----------|-------------|------------|
| `/api/*` | None (public) | 100/min |
| `/admin/*` | API Key | 10/min |
| Telegram webhook | HMAC signature | Unlimited |

### Admin API Key Validation

```typescript
// Middleware for admin routes
const validateAdminKey = (req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  
  if (!apiKey) {
    return res.status(401).json({ error: 'API key required' });
  }
  
  if (apiKey !== process.env.ADMIN_API_KEY) {
    // Log failed attempt
    logger.warn({
      ip: req.ip,
      path: req.path,
      timestamp: new Date().toISOString(),
    }, 'Invalid admin API key attempt');
    
    return res.status(403).json({ error: 'Invalid API key' });
  }
  
  next();
};
```

### Telegram Signature Verification

Already implemented in `routes/index.ts`:

```typescript
const verifyTelegramAuth = (botToken: string) => {
  return (req, res, next) => {
    const initData = req.headers['x-telegram-init-data'];
    // HMAC-SHA256 verification
    // ...
  };
};
```

---

## Compliance Checklist

### Pre-Production Checklist

- [ ] All secrets stored in 1Password or Secret Manager
- [ ] No secrets in version control (check git history!)
- [ ] API key rotation schedule documented
- [ ] VPC and firewall rules configured
- [ ] Cloud Armor WAF enabled
- [ ] Uptime monitoring configured
- [ ] Alert notifications configured
- [ ] Backup and recovery tested
- [ ] GDPR data region selected
- [ ] Security audit completed

### Periodic Security Tasks

| Task | Frequency | Owner |
|------|-----------|-------|
| Rotate API keys | 90 days | DevOps |
| Review access logs | Weekly | Security |
| Dependency audit | Monthly | Development |
| Penetration testing | Quarterly | Security |
| Disaster recovery drill | Bi-annually | DevOps |

### Incident Response

1. **Detection** - Monitoring alerts, user reports
2. **Containment** - Revoke compromised credentials
3. **Investigation** - Review logs, identify scope
4. **Remediation** - Patch vulnerability, rotate secrets
5. **Communication** - Notify affected users if required
6. **Post-mortem** - Document and improve processes

---

## Quick Reference Commands

```bash
# Load secrets from 1Password
eval $(op signin)
op inject -i .env.1password -o .env

# Verify integrity
npm run integrity:verify

# Create backup before changes
npm run loa:backup manual

# Rotate a secret
./scripts/rotate-api-key.sh sietch-collabland-api-key "new-key-value"

# Check security status
gcloud secrets list --filter="name:sietch"
gcloud run services describe sietch-unified-api --region=us-central1
```

---

## Support

For security issues, contact:
- Internal: security@yourcompany.com
- Collab.Land: support@collab.land
- GCP: https://cloud.google.com/support
