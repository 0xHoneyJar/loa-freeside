# Product Requirements Document (PRD)
## Sietch Unified - Cross-Platform Community Management

**Version:** 1.0.0  
**Last Updated:** December 25, 2024  
**Status:** Approved  
**Owner:** 0xHoneyJar  

---

## 1. Executive Summary

### 1.1 Product Vision

Sietch Unified is a cross-platform community management tool that enables Web3 community operators to identify and reward their most committed members ("Find the Others") across Discord and Telegram platforms using a unified identity layer powered by Collab.Land AccountKit.

### 1.2 Problem Statement

Web3 communities face three critical challenges:

1. **Fragmented Identity** - Members exist as separate entities across Discord, Telegram, and on-chain, making it impossible to recognize the same person across platforms.

2. **Shallow Conviction Signals** - Current token-gating only checks "do you hold X tokens?" but fails to measure true conviction (governance participation, holding duration, staking behavior).

3. **Platform Lock-in** - Communities building on Discord alone risk losing their most engaged members if Discord policies change or the platform declines.

### 1.3 Solution Overview

Sietch Unified creates a "Global Embassy" that:
- Bridges identities across Discord ↔ Telegram ↔ Wallet using Collab.Land AccountKit
- Evaluates multi-dimensional "conviction" using on-chain data from Dune Analytics
- Grants synchronized roles across all platforms when verification succeeds
- Maintains pseudonymous member profiles with privacy controls

---

## 2. Target Users

### 2.1 Primary Personas

#### Persona 1: Community Operator (Server Owner)
- **Who:** DAO contributors, protocol team members, community managers
- **Goals:** Identify top contributors, prevent Sybil attacks, create exclusive spaces
- **Pain Points:** Can't track same user across platforms, no way to measure conviction beyond token holdings
- **Success Metric:** Reduced moderation overhead, higher quality discussions in gated channels

#### Persona 2: Committed Member (Naib/Fedaykin)
- **Who:** Long-term holders, governance participants, active community members
- **Goals:** Get recognized for commitment, access exclusive content, connect with similar members
- **Pain Points:** Has to re-verify on every platform, no portable reputation
- **Success Metric:** Single verification grants access everywhere, profile shows earned reputation

#### Persona 3: Casual Participant
- **Who:** Token holders who don't actively participate
- **Goals:** Lurk, stay informed, occasionally participate
- **Pain Points:** Gets lumped in with bots/mercenaries
- **Success Metric:** Clear path to higher tiers through consistent engagement

### 2.2 Non-Target Users

- **Excluded:** Users seeking to game the system, bots, airdrop farmers
- **Reason:** The demurrage model and conviction metrics specifically disadvantage short-term, extractive behavior

---

## 3. Feature Requirements

### 3.1 Identity Bridge (P0 - Must Have)

#### 3.1.1 Wallet Verification
| Requirement | Description | Acceptance Criteria |
|-------------|-------------|---------------------|
| FR-001 | User can verify wallet ownership | User signs message, signature verified via Collab.Land |
| FR-002 | Verification session expires | Sessions timeout after 15 minutes |
| FR-003 | Multiple wallets supported | User can link up to 5 wallets to single identity |
| FR-004 | Re-verification flow | User can update linked wallet without losing profile |

#### 3.1.2 Cross-Platform Linking
| Requirement | Description | Acceptance Criteria |
|-------------|-------------|---------------------|
| FR-005 | Discord ↔ Wallet link | Discord UID stored with verified wallet |
| FR-006 | Telegram ↔ Wallet link | Telegram UID stored with verified wallet |
| FR-007 | Handshake workflow | Verify on Discord → auto-role on Telegram (and vice versa) |
| FR-008 | Unlink capability | User can disconnect platform from identity |

### 3.2 Conviction Engine (P0 - Must Have)

#### 3.2.1 Metric Evaluation
| Requirement | Description | Acceptance Criteria |
|-------------|-------------|---------------------|
| FR-009 | BGT holdings query | Fetch current BGT balance from Dune |
| FR-010 | Governance participation | Query governance votes from Dune |
| FR-011 | Staking/delegation | Query validator delegations |
| FR-012 | Never-redeemed filter | Disqualify if BGT ever redeemed |
| FR-013 | Composite scoring | Weight and combine metrics per YAML config |
| FR-014 | Ranking calculation | Compute percentile rank among all verified members |

#### 3.2.2 Tier Assignment
| Requirement | Description | Acceptance Criteria |
|-------------|-------------|---------------------|
| FR-015 | Naib tier (Top 7) | Rank 1-7 assigned "naib" tier |
| FR-016 | Fedaykin tier (8-69) | Rank 8-69 assigned "fedaykin" tier |
| FR-017 | No tier (70+) | Rank 70+ have no special tier |
| FR-018 | Tier change events | Log all tier transitions for audit |

### 3.3 Platform Integration (P0 - Must Have)

#### 3.3.1 Discord Bot
| Requirement | Description | Acceptance Criteria |
|-------------|-------------|---------------------|
| FR-019 | Slash commands | /verify, /profile, /rank, /leaderboard, /directory |
| FR-020 | Role assignment | Grant/revoke Discord roles based on tier |
| FR-021 | Stillsuit channels | Create private channels for Naib tier |
| FR-022 | DM onboarding | Welcome new members with verification flow |

#### 3.3.2 Telegram Bot
| Requirement | Description | Acceptance Criteria |
|-------------|-------------|---------------------|
| FR-023 | Bot commands | /start, /verify, /profile, /rank, /leaderboard |
| FR-024 | Mini App | Web-based verification and profile UI |
| FR-025 | Group management | Restrict group access based on tier |
| FR-026 | Inline keyboards | Navigation menus for commands |

### 3.4 Profile System (P1 - Should Have)

#### 3.4.1 Pseudonymous Profiles
| Requirement | Description | Acceptance Criteria |
|-------------|-------------|---------------------|
| FR-027 | Nym (display name) | User sets pseudonymous name (unique) |
| FR-028 | Bio | 280 character bio field |
| FR-029 | Visibility settings | public / members_only / private |
| FR-030 | Badge display | Show earned badges on profile |

#### 3.4.2 Member Directory
| Requirement | Description | Acceptance Criteria |
|-------------|-------------|---------------------|
| FR-031 | Browse members | Paginated list with filters |
| FR-032 | Filter by tier | Show only Naib, only Fedaykin, etc. |
| FR-033 | Filter by badge | Show only members with specific badge |
| FR-034 | Search by nym | Find member by display name |
| FR-035 | Privacy enforcement | Never expose wallet addresses in directory |

### 3.5 Activity & Reputation (P1 - Should Have)

#### 3.5.1 Activity Tracking
| Requirement | Description | Acceptance Criteria |
|-------------|-------------|---------------------|
| FR-036 | Message counting | Track messages per platform |
| FR-037 | Reaction tracking | Count reactions given/received |
| FR-038 | Voice participation | Track voice channel minutes |
| FR-039 | Activity score | Compute composite activity score |

#### 3.5.2 Demurrage Model
| Requirement | Description | Acceptance Criteria |
|-------------|-------------|---------------------|
| FR-040 | 10% decay | Activity score decays 10% every 6 hours |
| FR-041 | Decay logging | Log all decay applications |
| FR-042 | Floor value | Score cannot go below 0 |

### 3.6 Badge System (P2 - Nice to Have)

| Requirement | Description | Acceptance Criteria |
|-------------|-------------|---------------------|
| FR-043 | Tenure badges | first_wave (≤30d), veteran (≥90d), diamond_hands (≥180d) |
| FR-044 | Activity badges | engaged (>100), contributor (>500), pillar (>1000) |
| FR-045 | Tier badges | council (current/former Naib) |
| FR-046 | Achievement badges | survivor (maintained during downturn) |
| FR-047 | Streak badges | streak_master (30 day activity streak) |

---

## 4. Non-Functional Requirements

### 4.1 Performance

| ID | Requirement | Target |
|----|-------------|--------|
| NFR-001 | API response time | < 200ms p95 |
| NFR-002 | Conviction evaluation | < 5s per wallet |
| NFR-003 | Bot command response | < 1s |
| NFR-004 | Concurrent users | Support 10,000 verified members |

### 4.2 Reliability

| ID | Requirement | Target |
|----|-------------|--------|
| NFR-005 | Uptime | 99.9% (excluding planned maintenance) |
| NFR-006 | RPC grace period | 24 hours before role revocation on outage |
| NFR-007 | Data backup | Daily automated backups |
| NFR-008 | Recovery time | < 1 hour RTO |

### 4.3 Security

| ID | Requirement | Target |
|----|-------------|--------|
| NFR-009 | Secrets management | All secrets in vault (never in code) |
| NFR-010 | API authentication | Admin endpoints require API key |
| NFR-011 | Telegram verification | HMAC-SHA256 initData validation |
| NFR-012 | Rate limiting | 100 req/min per IP |
| NFR-013 | Wallet verification | Cryptographic signature via Collab.Land |

### 4.4 Privacy (GDPR Alignment)

| ID | Requirement | Target |
|----|-------------|--------|
| NFR-014 | Data minimization | Store only necessary identifiers |
| NFR-015 | Right to deletion | User can delete all data |
| NFR-016 | Data residency | Deployable to EU region |
| NFR-017 | No wallet exposure | Directory never shows addresses |
| NFR-018 | Chatham House Rules | Activity visible, holdings hidden |

### 4.5 Scalability

| ID | Requirement | Target |
|----|-------------|--------|
| NFR-019 | Horizontal scaling | Cloud Run auto-scales 0→N |
| NFR-020 | Database connections | Connection pooling (max 100) |
| NFR-021 | Cache strategy | Redis for sessions, 1hr conviction cache |

---

## 5. Technical Constraints

### 5.1 Platform Constraints

| Constraint | Description |
|------------|-------------|
| TC-001 | Must use Collab.Land AccountKit for identity (not custom solution) |
| TC-002 | Must use Dune Analytics for on-chain queries (black box) |
| TC-003 | Discord bot must use discord.js v14+ |
| TC-004 | Telegram bot must support Mini App (TWA) |
| TC-005 | Node.js 20+ required (modern runtime) |

### 5.2 Infrastructure Constraints

| Constraint | Description |
|------------|-------------|
| TC-006 | Deploy to Google Cloud Platform (Cloud Run) |
| TC-007 | PostgreSQL for persistent storage |
| TC-008 | Redis for session/cache storage |
| TC-009 | Terraform for infrastructure provisioning |

### 5.3 Integration Constraints

| Constraint | Description |
|------------|-------------|
| TC-010 | Berachain RPC for on-chain reads |
| TC-011 | Dune API rate limits apply |
| TC-012 | Collab.Land API rate limits apply |

---

## 6. Success Metrics

### 6.1 Adoption Metrics

| Metric | Target | Measurement |
|--------|--------|-------------|
| Verified members | 500 in 90 days | Count of UnifiedIdentity records |
| Cross-platform links | 30% have both Discord + Telegram | % with ≥2 LinkedAccounts |
| Profile completion | 50% have nym set | % with non-null nym |

### 6.2 Engagement Metrics

| Metric | Target | Measurement |
|--------|--------|-------------|
| Monthly active | 40% of verified members | Used bot in last 30 days |
| Directory views | 100/week | API calls to /directory |
| Badge earnings | 20% have ≥1 badge | % with UserBadge records |

### 6.3 Quality Metrics

| Metric | Target | Measurement |
|--------|--------|-------------|
| Verification success rate | > 95% | Completed / Started sessions |
| Bot command errors | < 1% | Error responses / Total commands |
| Role sync accuracy | 100% | Tier matches granted roles |

---

## 7. Release Plan

### 7.1 Phase 1: Foundation (Weeks 1-4)
- [x] Identity Bridge service
- [x] Conviction Engine service
- [x] PostgreSQL schema
- [x] Basic API endpoints

### 7.2 Phase 2: Platform Integration (Weeks 5-8)
- [x] Discord bot with slash commands
- [x] Telegram bot with commands
- [x] Telegram Mini App
- [x] Role synchronization

### 7.3 Phase 3: Social Layer (Weeks 9-12)
- [x] Profile system
- [x] Member directory
- [x] Badge system
- [x] Activity tracking

### 7.4 Phase 4: Enterprise Hardening (Weeks 13-16)
- [x] Three-zone architecture
- [x] Integrity verification
- [x] Terraform deployment
- [x] Security hardening
- [ ] Production deployment
- [ ] Monitoring & alerting

---

## 8. Open Questions

| ID | Question | Status | Resolution |
|----|----------|--------|------------|
| OQ-001 | Should we support Farcaster as third platform? | Deferred | Post-v1.0 consideration |
| OQ-002 | Multi-community support (one identity, many servers)? | Deferred | Architecture supports it |
| OQ-003 | Token for internal reputation? | Rejected | Soulbound approach preferred |

---

## 9. Appendices

### Appendix A: Terminology

| Term | Definition |
|------|------------|
| **Naib** | Top 7 ranked members (Dune reference: tribal leader) |
| **Fedaykin** | Ranks 8-69 (Dune reference: elite warriors) |
| **Stillsuit** | Private channel for highest tier members |
| **Conviction** | Multi-factor score measuring commitment |
| **Demurrage** | Time-decay applied to activity scores |
| **Nym** | Pseudonymous display name |
| **Handshake** | Cross-platform verification workflow |

### Appendix B: Related Documents

- [Software Design Document (SDD)](./SDD.md)
- [Security Hardening Guide](../docs/security/HARDENING_GUIDE.md)
- [Conviction Metrics Configuration](../config/conviction-metrics.yaml)

---

**Document Approval:**

| Role | Name | Date | Signature |
|------|------|------|-----------|
| Product Owner | 0xHoneyJar | 2024-12-25 | ✅ Approved |
| Tech Lead | - | - | Pending |
| Security | - | - | Pending |
