# Software Design Document (SDD)
## Sietch Unified - Technical Architecture

**Version:** 2.1.0  
**Last Updated:** December 25, 2024  
**Status:** Approved  
**Author:** Claude (AI Architect)  
**Reviewer:** 0xHoneyJar  

---

## 1. Introduction

### 1.1 Purpose

This Software Design Document (SDD) provides a comprehensive technical specification for Sietch Unified, a cross-platform community management system. It serves as the authoritative reference for developers, reviewers, and auditors.

### 1.2 Scope

This document covers:
- System architecture and component design
- Data models and database schema
- API specifications
- Security architecture
- Deployment topology
- Integration patterns
- **Subscription billing architecture (NEW in v2.1)**

### 1.3 References

| Document | Location |
|----------|----------|
| Product Requirements | `state/PRD.md` |
| Conviction Metrics Config | `config/conviction-metrics.yaml` |
| Subscription Tiers Config | `config/subscription-tiers.yaml` |
| Security Hardening Guide | `docs/security/HARDENING_GUIDE.md` |
| Loa Framework Manifest | `loa.yaml` |
| Bootstrap Prompt | `BOOTSTRAP_PROMPT.md` |

---

## 2. System Architecture

### 2.1 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           EXTERNAL SERVICES                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│   ┌─────────────┐   ┌─────────────┐   ┌─────────────┐   ┌─────────────┐    │
│   │  Collab.Land │   │    Dune     │   │  Berachain  │   │   Discord   │    │
│   │  AccountKit  │   │  Analytics  │   │     RPC     │   │     API     │    │
│   └──────┬──────┘   └──────┬──────┘   └──────┬──────┘   └──────┬──────┘    │
│          │                 │                 │                 │            │
│   ┌──────┴──────┐   ┌──────┴──────┐   ┌──────┴──────┐   ┌──────┴──────┐    │
│   │  Telegram   │   │   Stripe    │   │    GCP      │   │   trigger   │    │
│   │     API     │   │   Billing   │   │   Secrets   │   │     .dev    │    │
│   └──────┬──────┘   └──────┬──────┘   └──────┬──────┘   └──────┬──────┘    │
│          │                 │                 │                 │            │
└──────────┼─────────────────┼─────────────────┼─────────────────┼────────────┘
           │                 │                 │                 │
           ▼                 ▼                 ▼                 ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         SIETCH UNIFIED BACKEND                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                         API GATEWAY (Hono)                          │   │
│   │                                                                      │   │
│   │   ┌─────────────┐   ┌─────────────┐   ┌─────────────────────────┐   │   │
│   │   │   /api/*    │   │  /admin/*   │   │      /webhooks/*        │   │   │
│   │   │  (public)   │   │ (API key)   │   │   (Stripe webhooks)     │   │   │
│   │   └─────────────┘   └─────────────┘   └─────────────────────────┘   │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                         │
│                                    ▼                                         │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                         SERVICE LAYER                                │   │
│   │                                                                      │   │
│   │   ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐    │   │
│   │   │ IdentityBridge  │  │ ConvictionEngine│  │   Gatekeeper    │    │   │
│   │   │    Service      │  │     Service     │  │    Service      │    │   │
│   │   └────────┬────────┘  └────────┬────────┘  └────────┬────────┘    │   │
│   │            │                    │                    │              │   │
│   │   ┌────────┴────────┐  ┌────────┴────────┐  ┌────────┴────────┐    │   │
│   │   │   DuneClient    │  │  ProfileService │  │  BadgeService   │    │   │
│   │   │                 │  │                 │  │                 │    │   │
│   │   └─────────────────┘  └─────────────────┘  └─────────────────┘    │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                         │
│                                    ▼                                         │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                         DATA LAYER                                   │   │
│   │                                                                      │   │
│   │   ┌─────────────────┐              ┌─────────────────┐              │   │
│   │   │   PostgreSQL    │              │      Redis      │              │   │
│   │   │   (Prisma ORM)  │              │   (ioredis)     │              │   │
│   │   │                 │              │                 │              │   │
│   │   │  • Identities   │              │  • Sessions     │              │   │
│   │   │  • Profiles     │              │  • Cache        │              │   │
│   │   │  • Badges       │              │  • Rate limits  │              │   │
│   │   │  • Activity     │              │                 │              │   │
│   │   └─────────────────┘              └─────────────────┘              │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
           │                                               │
           ▼                                               ▼
┌─────────────────────────────┐             ┌─────────────────────────────┐
│       DISCORD BOT           │             │       TELEGRAM BOT          │
│                             │             │                             │
│   ┌─────────────────────┐   │             │   ┌─────────────────────┐   │
│   │    discord.js v14   │   │             │   │       grammy        │   │
│   │                     │   │             │   │                     │   │
│   │  • Slash Commands   │   │             │   │  • Commands         │   │
│   │  • Role Manager     │   │             │   │  • Inline Menus     │   │
│   │  • Event Handlers   │   │             │   │  • Web App Launch   │   │
│   └─────────────────────┘   │             │   └─────────────────────┘   │
│                             │             │                             │
└─────────────────────────────┘             │   ┌─────────────────────┐   │
                                            │   │   TELEGRAM MINIAPP  │   │
                                            │   │                     │   │
                                            │   │  • React + Vite     │   │
                                            │   │  • @twa-dev/sdk     │   │
                                            │   │  • Directory UI     │   │
                                            │   └─────────────────────┘   │
                                            │                             │
                                            └─────────────────────────────┘
```

### 2.2 Component Responsibilities

| Component | Responsibility | Technology |
|-----------|----------------|------------|
| API Gateway | Route requests, rate limiting, authentication | Express.js |
| IdentityBridge | Cross-platform identity linking | TypeScript |
| ConvictionEngine | Metric evaluation and ranking | TypeScript + Dune |
| CollabLandClient | AccountKit API integration | TypeScript |
| DuneClient | On-chain data queries | TypeScript |
| Discord Bot | Discord platform integration | discord.js v14 |
| Telegram Bot | Telegram platform integration | grammy |
| Mini App | Rich Telegram UI | React + TWA SDK |

### 2.3 Three-Zone Architecture

```
sietch-unified/
├── system/                    # IMMUTABLE - Framework code
│   └── core/
│       ├── integrity.ts       # Checksum verification
│       └── framework.ts       # Loa framework core
│
├── state/                     # PRESERVED - Project memory
│   ├── PRD.md                 # Product requirements
│   ├── SDD.md                 # This document
│   ├── grimoire.yaml          # Project state
│   └── checksums.json         # Integrity manifest
│
├── app/                       # DEVELOPER-OWNED - Custom code
│   └── (custom extensions)
│
├── packages/                  # Application code
│   ├── server/                # API server
│   ├── discord-bot/           # Discord integration
│   ├── telegram-bot/          # Telegram integration
│   ├── telegram-miniapp/      # Mini App UI
│   └── shared/                # Shared types/utils
│
└── infrastructure/            # Deployment config
    └── terraform/             # GCP provisioning
```

---

## 3. Data Model

### 3.1 Entity Relationship Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              DATA MODEL                                      │
└─────────────────────────────────────────────────────────────────────────────┘

    ┌──────────────────────┐         ┌──────────────────────┐
    │   UnifiedIdentity    │         │   VerificationSession│
    ├──────────────────────┤         ├──────────────────────┤
    │ id: UUID (PK)        │◄────────┤ id: UUID (PK)        │
    │ primaryWallet: String│         │ identityId: UUID (FK)│
    │ tier: String         │         │ platform: Enum       │
    │ rank: Int?           │         │ platformUserId: Str  │
    │ createdAt: DateTime  │         │ nonce: String        │
    │ updatedAt: DateTime  │         │ status: Enum         │
    └──────────┬───────────┘         │ expiresAt: DateTime  │
               │                     └──────────────────────┘
               │
    ┌──────────┴───────────┐
    │                      │
    ▼                      ▼
┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
│   LinkedWallet   │  │   LinkedAccount  │  │    UserProfile   │
├──────────────────┤  ├──────────────────┤  ├──────────────────┤
│ id: UUID (PK)    │  │ id: UUID (PK)    │  │ id: UUID (PK)    │
│ identityId (FK)  │  │ identityId (FK)  │  │ identityId (FK)  │
│ address: String  │  │ platform: Enum   │  │ nym: String?     │
│ chain: String    │  │ platformUserId   │  │ bio: String?     │
│ isPrimary: Bool  │  │ username: String?│  │ visibility: Enum │
│ verifiedAt       │  │ verifiedAt       │  │ activityScore    │
└──────────────────┘  └──────────────────┘  │ tenureStart      │
                                            └────────┬─────────┘
                                                     │
                              ┌──────────────────────┼──────────────────────┐
                              │                      │                      │
                              ▼                      ▼                      ▼
                    ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
                    │    UserBadge     │  │   ActivityEntry  │  │ ActivityDecayLog │
                    ├──────────────────┤  ├──────────────────┤  ├──────────────────┤
                    │ id: UUID (PK)    │  │ id: UUID (PK)    │  │ id: UUID (PK)    │
                    │ profileId (FK)   │  │ profileId (FK)   │  │ appliedAt        │
                    │ type: Enum       │  │ platform: Enum   │  │ decayFactor      │
                    │ earnedAt         │  │ type: Enum       │  │ affectedProfiles │
                    │ metadata: JSON   │  │ count: Int       │  │ totalDecayed     │
                    └──────────────────┘  │ recordedAt       │  └──────────────────┘
                                          └──────────────────┘

                    ┌──────────────────┐  ┌──────────────────┐
                    │  ConvictionCache │  │   RoleSyncEvent  │
                    ├──────────────────┤  ├──────────────────┤
                    │ id: UUID (PK)    │  │ id: UUID (PK)    │
                    │ walletAddress    │  │ identityId (FK)  │
                    │ score: Float     │  │ platform: Enum   │
                    │ rank: Int        │  │ previousTier     │
                    │ tier: String     │  │ newTier: String  │
                    │ metrics: JSON    │  │ reason: String   │
                    │ evaluatedAt      │  │ syncedAt         │
                    │ expiresAt        │  │ success: Bool    │
                    └──────────────────┘  └──────────────────┘
```

### 3.2 Database Schema Details

#### 3.2.1 UnifiedIdentity

```sql
CREATE TABLE unified_identities (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  primary_wallet  VARCHAR(42) NOT NULL UNIQUE,
  tier            VARCHAR(20) DEFAULT 'none',
  rank            INTEGER,
  created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_identity_tier ON unified_identities(tier);
CREATE INDEX idx_identity_rank ON unified_identities(rank);
```

#### 3.2.2 LinkedAccount

```sql
CREATE TABLE linked_accounts (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  identity_id      UUID NOT NULL REFERENCES unified_identities(id) ON DELETE CASCADE,
  platform         VARCHAR(20) NOT NULL, -- 'discord' | 'telegram'
  platform_user_id VARCHAR(100) NOT NULL,
  username         VARCHAR(100),
  verified_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  UNIQUE(platform, platform_user_id)
);

CREATE INDEX idx_account_platform ON linked_accounts(platform, platform_user_id);
```

#### 3.2.3 UserProfile

```sql
CREATE TABLE user_profiles (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  identity_id     UUID NOT NULL UNIQUE REFERENCES unified_identities(id) ON DELETE CASCADE,
  nym             VARCHAR(50) UNIQUE,
  bio             VARCHAR(280),
  visibility      VARCHAR(20) DEFAULT 'members_only', -- 'public' | 'members_only' | 'private'
  activity_score  DECIMAL(10, 2) DEFAULT 0,
  tenure_start    TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_profile_nym ON user_profiles(nym);
CREATE INDEX idx_profile_visibility ON user_profiles(visibility);
CREATE INDEX idx_profile_activity ON user_profiles(activity_score DESC);
```

### 3.3 Cache Strategy

| Data | Store | TTL | Invalidation |
|------|-------|-----|--------------|
| Verification sessions | Redis | 15 min | On complete/expire |
| Conviction scores | Redis | 1 hour | On re-evaluation |
| User sessions | Redis | 24 hours | On logout |
| API rate limits | Redis | 1 min | Sliding window |
| Identity lookups | Redis | 5 min | On update |

---

## 4. API Specification

### 4.1 API Overview

| Endpoint Group | Base Path | Auth | Rate Limit |
|----------------|-----------|------|------------|
| Identity | `/api/identity` | None | 100/min |
| Conviction | `/api/conviction` | None | 100/min |
| Profile | `/api/profile` | None | 100/min |
| Directory | `/api/directory` | None | 100/min |
| Admin | `/admin` | API Key | 10/min |

### 4.2 Identity Endpoints

#### POST /api/identity/session

Create verification session.

**Request:**
```json
{
  "platform": "discord",
  "platformUserId": "123456789",
  "platformUsername": "user#1234"
}
```

**Response:**
```json
{
  "sessionId": "uuid",
  "verificationUrl": "https://...",
  "expiresAt": "2024-12-25T12:15:00Z"
}
```

#### POST /api/identity/session/:sessionId/complete

Complete verification with wallet signature.

**Request:**
```json
{
  "walletAddress": "0x...",
  "signature": "0x...",
  "message": "Sign this message..."
}
```

**Response:**
```json
{
  "success": true,
  "identityId": "uuid",
  "tier": "fedaykin",
  "rank": 42
}
```

### 4.3 Conviction Endpoints

#### GET /api/conviction/:walletAddress

Evaluate conviction for wallet.

**Response:**
```json
{
  "wallet": "0x...",
  "score": 0.85,
  "rank": 15,
  "tier": "fedaykin",
  "metrics": {
    "bgt_holdings": { "raw": 1500, "normalized": 0.75, "weight": 0.4 },
    "governance": { "raw": 12, "normalized": 0.90, "weight": 0.3 },
    "engagement": { "raw": 250, "normalized": 0.85, "weight": 0.3 }
  },
  "evaluatedAt": "2024-12-25T12:00:00Z",
  "expiresAt": "2024-12-25T13:00:00Z"
}
```

### 4.4 Profile Endpoints

#### GET /api/profile/discord/:discordId

Get profile by Discord ID.

**Response:**
```json
{
  "identityId": "uuid",
  "nym": "SpiceMaster",
  "bio": "Walking without rhythm",
  "tier": "naib",
  "rank": 3,
  "badges": [
    { "type": "first_wave", "earnedAt": "2024-10-01T00:00:00Z" },
    { "type": "council", "earnedAt": "2024-11-15T00:00:00Z" }
  ],
  "activityScore": 450.5,
  "tenureDays": 85,
  "visibility": "public"
}
```

#### PUT /api/profile/nym

Update display name.

**Request:**
```json
{
  "identityId": "uuid",
  "nym": "NewDisplayName"
}
```

**Response:**
```json
{
  "success": true,
  "nym": "NewDisplayName"
}
```

### 4.5 Directory Endpoints

#### GET /api/directory

Browse members with filters.

**Query Parameters:**
| Param | Type | Description |
|-------|------|-------------|
| tier | string | Filter by tier (naib, fedaykin) |
| badge | string | Filter by badge type |
| search | string | Search by nym |
| minActivityScore | number | Minimum activity score |
| platform | string | Filter by platform |
| page | number | Page number (default: 1) |
| limit | number | Results per page (default: 20, max: 100) |
| sort | string | Sort field (rank, activity, tenure) |

**Response:**
```json
{
  "members": [
    {
      "nym": "SpiceMaster",
      "tier": "naib",
      "rank": 3,
      "badges": ["first_wave", "council"],
      "activityScore": 450.5,
      "tenureDays": 85,
      "platforms": ["discord", "telegram"]
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 150,
    "pages": 8
  }
}
```

### 4.6 Admin Endpoints

All admin endpoints require `X-API-Key` header.

#### POST /admin/refresh-rankings

Force re-evaluation of all members.

**Response:**
```json
{
  "success": true,
  "evaluated": 150,
  "promotions": 3,
  "demotions": 2,
  "duration": "45.2s"
}
```

#### GET /admin/stats

System statistics.

**Response:**
```json
{
  "identities": 523,
  "profiles": 489,
  "tiers": {
    "naib": 7,
    "fedaykin": 62,
    "none": 454
  },
  "platforms": {
    "discord": 498,
    "telegram": 312,
    "both": 287
  },
  "recentVerifications": 15,
  "cacheHitRate": 0.85
}
```

---

## 5. Security Architecture

### 5.1 Authentication Flows

#### 5.1.1 Wallet Verification Flow

```
┌─────────┐     ┌─────────┐     ┌─────────────┐     ┌───────────┐
│  User   │     │   Bot   │     │  API Server │     │ Collab.Land│
└────┬────┘     └────┬────┘     └──────┬──────┘     └─────┬─────┘
     │               │                 │                   │
     │  /verify      │                 │                   │
     │──────────────►│                 │                   │
     │               │  POST /session  │                   │
     │               │────────────────►│                   │
     │               │                 │  Generate nonce   │
     │               │  {sessionId}    │◄──────────────────│
     │               │◄────────────────│                   │
     │  Verify Link  │                 │                   │
     │◄──────────────│                 │                   │
     │               │                 │                   │
     │  Click & Sign │                 │                   │
     │───────────────────────────────────────────────────► │
     │               │                 │  Verify signature │
     │               │                 │◄──────────────────│
     │               │                 │   {valid: true}   │
     │               │  POST /complete │──────────────────►│
     │               │◄────────────────│                   │
     │  ✅ Verified   │                 │                   │
     │◄──────────────│                 │                   │
     │               │                 │                   │
```

#### 5.1.2 Telegram Mini App Auth Flow

```
┌─────────┐     ┌──────────┐     ┌─────────────┐
│  User   │     │ Mini App │     │  API Server │
└────┬────┘     └────┬─────┘     └──────┬──────┘
     │               │                  │
     │  Open App     │                  │
     │──────────────►│                  │
     │               │                  │
     │               │  initData        │
     │               │  (signed by TG)  │
     │               │                  │
     │               │  GET /profile    │
     │               │  X-Telegram-Init-Data: ...
     │               │─────────────────►│
     │               │                  │
     │               │                  │  Verify HMAC-SHA256
     │               │                  │  with BOT_TOKEN
     │               │                  │
     │               │  {profile}       │
     │               │◄─────────────────│
     │  Profile View │                  │
     │◄──────────────│                  │
```

### 5.2 Authorization Matrix

| Endpoint | Anonymous | Verified | Admin |
|----------|-----------|----------|-------|
| GET /api/directory | ✅ | ✅ | ✅ |
| GET /api/profile/* | ✅ | ✅ | ✅ |
| PUT /api/profile/nym | ❌ | ✅ (own) | ✅ |
| GET /api/conviction/* | ✅ | ✅ | ✅ |
| POST /api/identity/session | ✅ | ✅ | ✅ |
| POST /admin/* | ❌ | ❌ | ✅ |
| GET /admin/stats | ❌ | ❌ | ✅ |

### 5.3 Secret Management

```
┌─────────────────────────────────────────────────────────────────┐
│                    SECRET MANAGEMENT FLOW                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   ┌─────────────┐     ┌─────────────┐     ┌─────────────┐       │
│   │  Developer  │     │  1Password  │     │  GCP Secret │       │
│   │   Laptop    │     │    Vault    │     │   Manager   │       │
│   └──────┬──────┘     └──────┬──────┘     └──────┬──────┘       │
│          │                   │                   │               │
│          │ op inject         │                   │               │
│          │──────────────────►│                   │               │
│          │                   │                   │               │
│          │ .env file         │                   │               │
│          │◄──────────────────│                   │               │
│          │                   │                   │               │
│   LOCAL DEVELOPMENT          │                   │               │
│                              │                   │               │
│   ─────────────────────────────────────────────────────────     │
│                                                                  │
│   PRODUCTION (Cloud Run)                                         │
│                              │                   │               │
│   ┌─────────────┐            │                   │               │
│   │  Cloud Run  │            │    Terraform      │               │
│   │   Service   │◄───────────────────────────────│               │
│   └─────────────┘            │   provisions      │               │
│          │                   │   & injects       │               │
│          │                   │                   │               │
│          │ process.env.*     │                   │               │
│          │                   │                   │               │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### 5.4 Rate Limiting

| Endpoint | Limit | Window | Action on Exceed |
|----------|-------|--------|------------------|
| /api/* | 100 | 1 min | 429 Too Many Requests |
| /admin/* | 10 | 1 min | 429 + 10 min ban |
| /api/identity/session | 5 | 5 min | 429 + Captcha |

---

## 6. Deployment Architecture

### 6.1 GCP Topology

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        GOOGLE CLOUD PLATFORM                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                         VPC NETWORK                                  │   │
│   │                    (sietch-unified-vpc)                              │   │
│   │                                                                      │   │
│   │   ┌─────────────────────────────────────────────────────────────┐   │   │
│   │   │                    PRIVATE SUBNET                            │   │   │
│   │   │                    (10.0.0.0/24)                             │   │   │
│   │   │                                                              │   │   │
│   │   │   ┌─────────────┐              ┌─────────────┐              │   │   │
│   │   │   │  Cloud SQL  │              │ Memorystore │              │   │   │
│   │   │   │ PostgreSQL  │              │   Redis     │              │   │   │
│   │   │   │             │              │             │              │   │   │
│   │   │   │ 10.0.0.10   │              │ 10.0.0.20   │              │   │   │
│   │   │   └─────────────┘              └─────────────┘              │   │   │
│   │   │                                                              │   │   │
│   │   └─────────────────────────────────────────────────────────────┘   │   │
│   │                              ▲                                       │   │
│   │                              │ VPC Connector                         │   │
│   │                              │ (10.8.0.0/28)                         │   │
│   │                              │                                       │   │
│   └──────────────────────────────┼───────────────────────────────────────┘   │
│                                  │                                           │
│   ┌──────────────────────────────┴───────────────────────────────────────┐   │
│   │                         CLOUD RUN                                     │   │
│   │                                                                       │   │
│   │   ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐      │   │
│   │   │   API Server    │  │   Discord Bot   │  │  Telegram Bot   │      │   │
│   │   │                 │  │                 │  │                 │      │   │
│   │   │  Min: 1 (prod)  │  │  Min: 1 (always)│  │  Min: 0 (scale) │      │   │
│   │   │  Max: 10        │  │  Max: 1         │  │  Max: 3         │      │   │
│   │   │                 │  │                 │  │                 │      │   │
│   │   │  Port: 3001     │  │  (gateway)      │  │  (webhook)      │      │   │
│   │   └────────┬────────┘  └─────────────────┘  └─────────────────┘      │   │
│   │            │                                                          │   │
│   └────────────┼──────────────────────────────────────────────────────────┘   │
│                │                                                              │
│                ▼                                                              │
│   ┌────────────────────────────────────────────────────────────────────────┐ │
│   │                      CLOUD LOAD BALANCER                                │ │
│   │                     (with Cloud Armor WAF)                              │ │
│   └────────────────────────────────────────────────────────────────────────┘ │
│                                  │                                           │
└──────────────────────────────────┼───────────────────────────────────────────┘
                                   │
                                   ▼
                              ┌─────────┐
                              │ INTERNET│
                              └─────────┘
```

### 6.2 Scaling Configuration

| Service | Min Instances | Max Instances | CPU | Memory |
|---------|---------------|---------------|-----|--------|
| API Server | 1 (prod) / 0 (dev) | 10 | 1 | 512Mi |
| Discord Bot | 1 | 1 | 1 | 512Mi |
| Telegram Bot | 0 | 3 | 1 | 512Mi |

### 6.3 Regional Deployment

| Region Code | GCP Region | Use Case |
|-------------|------------|----------|
| us | us-central1 | Default |
| eu | europe-west1 | GDPR compliance |
| asia | asia-southeast1 | APAC users |

---

## 7. Integration Patterns

### 7.1 Collab.Land Integration

```typescript
// AccountKit API calls
interface CollabLandClient {
  // Identity resolution
  getIdentityByWallet(address: string): Promise<Identity>;
  getIdentityByDiscord(discordId: string): Promise<Identity>;
  getIdentityByTelegram(telegramId: string): Promise<Identity>;
  
  // Verification
  generateVerificationMessage(nonce?: string): Promise<VerifyMessage>;
  verifyWalletSignature(request: VerifyRequest): Promise<VerifyResult>;
  
  // Account linking
  linkAccount(request: LinkRequest): Promise<LinkResult>;
  unlinkAccount(wallet: string, platform: string): Promise<void>;
  
  // Token gating
  checkTokenGate(wallet: string, rules: TokenRule[]): Promise<GateResult>;
}
```

### 7.2 Dune Analytics Integration

```typescript
// Black-box query execution
interface DuneClient {
  // Execute pre-defined queries
  executeQuery(queryId: number, params?: QueryParams): Promise<QueryResult>;
  
  // Get query results
  getQueryResults(executionId: string): Promise<QueryResult>;
  
  // Polling with timeout
  waitForResults(executionId: string, timeout: number): Promise<QueryResult>;
}

// Query IDs (configured in .env)
const DUNE_QUERIES = {
  BGT_HOLDERS: 12345,
  BGT_REDEEMERS: 12346,
  GOVERNANCE_VOTES: 12347,
};
```

### 7.3 Event Flow

```
┌────────────────────────────────────────────────────────────────┐
│                      EVENT FLOW                                 │
├────────────────────────────────────────────────────────────────┤
│                                                                 │
│   Verification Complete                                         │
│         │                                                       │
│         ▼                                                       │
│   ┌─────────────┐     ┌─────────────┐     ┌─────────────┐      │
│   │  Evaluate   │────►│   Update    │────►│    Sync     │      │
│   │ Conviction  │     │    Tier     │     │    Roles    │      │
│   └─────────────┘     └─────────────┘     └──────┬──────┘      │
│                                                  │              │
│                              ┌───────────────────┼───────────┐  │
│                              │                   │           │  │
│                              ▼                   ▼           ▼  │
│                        ┌─────────┐         ┌─────────┐      │  │
│                        │ Discord │         │Telegram │      │  │
│                        │  Roles  │         │  Groups │      │  │
│                        └─────────┘         └─────────┘      │  │
│                                                              │  │
│   ─────────────────────────────────────────────────────────────│
│                                                                 │
│   Scheduled: Every 6 Hours                                      │
│         │                                                       │
│         ▼                                                       │
│   ┌─────────────┐     ┌─────────────┐     ┌─────────────┐      │
│   │   Query     │────►│  Recompute  │────►│   Detect    │      │
│   │    Dune     │     │  Rankings   │     │   Changes   │      │
│   └─────────────┘     └─────────────┘     └──────┬──────┘      │
│                                                  │              │
│                                                  ▼              │
│                                           ┌─────────────┐      │
│                                           │ Sync Roles  │      │
│                                           │ (promotions/│      │
│                                           │  demotions) │      │
│                                           └─────────────┘      │
│                                                                 │
└────────────────────────────────────────────────────────────────┘
```

---

## 8. Error Handling

### 8.1 Error Categories

| Category | HTTP Code | Retry | Example |
|----------|-----------|-------|---------|
| Validation | 400 | No | Invalid wallet address format |
| Authentication | 401 | No | Missing API key |
| Authorization | 403 | No | Insufficient permissions |
| Not Found | 404 | No | Identity not found |
| Rate Limited | 429 | Yes (with backoff) | Too many requests |
| External Service | 502 | Yes | Dune API timeout |
| Internal | 500 | Yes (limited) | Database connection failed |

### 8.2 Graceful Degradation

| Failure | Fallback Behavior |
|---------|-------------------|
| Dune API down | Return cached conviction, extend TTL |
| Collab.Land down | Queue verification, notify user |
| Redis down | Bypass cache, hit database |
| Discord API down | Queue role updates, retry |
| Telegram API down | Queue messages, retry |

### 8.3 Circuit Breaker

```typescript
// Circuit breaker for external services
interface CircuitBreaker {
  state: 'closed' | 'open' | 'half-open';
  failureCount: number;
  lastFailure: Date;
  
  // Thresholds
  failureThreshold: 5;
  resetTimeout: 60000; // 1 minute
}
```

---

## 9. Monitoring & Observability

### 9.1 Metrics

| Metric | Type | Labels |
|--------|------|--------|
| http_requests_total | Counter | method, path, status |
| http_request_duration_seconds | Histogram | method, path |
| conviction_evaluations_total | Counter | tier, success |
| conviction_evaluation_duration_seconds | Histogram | - |
| role_syncs_total | Counter | platform, success |
| cache_hits_total | Counter | cache_type |
| cache_misses_total | Counter | cache_type |

### 9.2 Logging

```typescript
// Structured logging with pino
logger.info({
  event: 'verification_complete',
  identityId: 'uuid',
  platform: 'discord',
  tier: 'fedaykin',
  rank: 42,
  duration: 1250,
});
```

### 9.3 Alerting

| Alert | Condition | Severity |
|-------|-----------|----------|
| API Down | Uptime check fails 3x | Critical |
| High Error Rate | > 5% 5xx in 5 min | High |
| High Latency | p95 > 2s for 5 min | Medium |
| Dune API Errors | > 10 failures in 1 hour | Medium |
| Database Connection | Connection pool exhausted | Critical |

---

## 10. Appendices

### Appendix A: Technology Stack

| Layer | Technology | Version |
|-------|------------|---------|
| Runtime | Node.js | 20+ |
| Language | TypeScript | 5.3+ |
| API Framework | Express.js | 4.18+ |
| ORM | Prisma | 5.7+ |
| Discord SDK | discord.js | 14+ |
| Telegram SDK | grammy | 1.19+ |
| Mini App | React + Vite | 18 / 5 |
| Database | PostgreSQL | 16 |
| Cache | Redis | 7 |
| IaC | Terraform | 1.5+ |
| CI/CD | GitHub Actions | - |
| Cloud | Google Cloud Platform | - |

### Appendix B: API Error Codes

| Code | Message | Resolution |
|------|---------|------------|
| E001 | Invalid wallet address | Check address format |
| E002 | Session expired | Create new session |
| E003 | Signature verification failed | Re-sign message |
| E004 | Identity not found | Verify first |
| E005 | Nym already taken | Choose different nym |
| E006 | Rate limit exceeded | Wait and retry |
| E007 | External service unavailable | Retry with backoff |

### Appendix C: Configuration Reference

See `config/conviction-metrics.yaml` for full conviction configuration options.

---

**Document Approval:**

| Role | Name | Date | Signature |
|------|------|------|-----------|
| Tech Lead | - | - | Pending |
| Security Auditor | - | - | Pending |
| Product Owner | 0xHoneyJar | 2024-12-25 | ✅ Approved |
