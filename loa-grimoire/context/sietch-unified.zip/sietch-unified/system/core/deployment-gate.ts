/**
 * =============================================================================
 * SIETCH UNIFIED - DEPLOYMENT GATE SERVICE
 * =============================================================================
 * 
 * Enterprise-grade deployment gating that BLOCKS deployment when:
 * 1. System Zone has been tampered with (integrity violation)
 * 2. TruffleHog/Gitleaks detects secrets in codebase
 * 3. Security audit has not been approved
 * 4. Tech Lead has not approved architecture
 * 
 * ENTERPRISE STANDARD: AWS CodePipeline / Google Cloud Build quality gates.
 * 
 * @module system/core/deployment-gate
 */

import { execSync } from 'child_process';
import * as fs from 'fs';
import * as path from 'path';
import { IntegrityVerifier, VerificationResult } from './integrity';

// =============================================================================
// TYPES
// =============================================================================

export interface GateCheck {
  name: string;
  status: 'passed' | 'failed' | 'skipped' | 'pending';
  required: boolean;
  message: string;
  details?: Record<string, unknown>;
  executedAt?: Date;
  severity?: 'info' | 'warning' | 'high' | 'critical';
}

export interface DeploymentGateResult {
  canDeploy: boolean;
  checks: GateCheck[];
  blockers: string[];
  warnings: string[];
  timestamp: Date;
  approvals: {
    techLead: boolean;
    securityAuditor: boolean;
  };
  severitySummary: {
    critical: number;
    high: number;
    warning: number;
    info: number;
  };
  hardBlock: boolean;  // True if critical violation detected
  hardBlockReason?: string;
}

export interface GateConfig {
  requireIntegrityCheck: boolean;
  requireSecretsScan: boolean;
  requireTechLeadApproval: boolean;
  requireSecurityApproval: boolean;
  allowedBranches: string[];
  secretScanners: ('trufflehog' | 'gitleaks')[];
}

// =============================================================================
// DEFAULT CONFIGURATION
// =============================================================================

const DEFAULT_CONFIG: GateConfig = {
  requireIntegrityCheck: true,
  requireSecretsScan: true,
  requireTechLeadApproval: true,
  requireSecurityApproval: true,
  allowedBranches: ['main', 'release/*', 'hotfix/*'],
  secretScanners: ['trufflehog'],
};

// =============================================================================
// DEPLOYMENT GATE SERVICE
// =============================================================================

export class DeploymentGateService {
  private config: GateConfig;
  private rootDir: string;
  private approvalsFile: string;

  constructor(rootDir: string = process.cwd(), config?: Partial<GateConfig>) {
    this.rootDir = rootDir;
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.approvalsFile = path.join(rootDir, 'state', 'deployment-approvals.json');
  }

  // ===========================================================================
  // MAIN GATE CHECK
  // ===========================================================================

  /**
   * Run all deployment gate checks.
   * Returns whether deployment should proceed.
   */
  async runAllChecks(): Promise<DeploymentGateResult> {
    const checks: GateCheck[] = [];
    const blockers: string[] = [];
    const warnings: string[] = [];
    let hardBlock = false;
    let hardBlockReason: string | undefined;

    const severitySummary = {
      critical: 0,
      high: 0,
      warning: 0,
      info: 0,
    };

    // 1. System Zone Integrity Check (CRITICAL)
    if (this.config.requireIntegrityCheck) {
      const integrityCheck = await this.checkSystemIntegrity();
      checks.push(integrityCheck);
      
      if (integrityCheck.status === 'failed') {
        // System Zone violations are CRITICAL - immediate hard block
        if (integrityCheck.severity === 'critical') {
          hardBlock = true;
          hardBlockReason = 'CRITICAL: System Zone integrity violation. Build cannot proceed.';
          severitySummary.critical++;
        } else {
          severitySummary.high++;
        }
        blockers.push('CRITICAL: System Zone integrity violation detected. Deployment blocked.');
      }
    }

    // 2. Secrets Scan (TruffleHog/Gitleaks)
    if (this.config.requireSecretsScan) {
      const secretsCheck = await this.checkForSecrets();
      checks.push(secretsCheck);
      
      if (secretsCheck.status === 'failed') {
        // Secrets in codebase are CRITICAL - immediate hard block
        hardBlock = true;
        hardBlockReason = 'CRITICAL: Secrets detected in codebase. Build cannot proceed.';
        severitySummary.critical++;
        blockers.push('CRITICAL: Secrets detected in codebase. Run `trufflehog filesystem .` for details.');
      }
    }

    // 3. Branch Check
    const branchCheck = this.checkBranch();
    checks.push(branchCheck);
    
    if (branchCheck.status === 'failed') {
      severitySummary.warning++;
      warnings.push(`Warning: Deploying from non-standard branch.`);
    }

    // 4. Dependency Vulnerabilities (npm audit)
    const depCheck = await this.checkDependencies();
    checks.push(depCheck);
    
    if (depCheck.status === 'failed') {
      severitySummary.warning++;
      warnings.push('Warning: Dependency vulnerabilities detected. Run `npm audit fix`.');
    }

    // 5. Protected Path Check (NEW - ensures System Zone not modified via overrides)
    const protectedPathCheck = await this.checkProtectedPaths();
    checks.push(protectedPathCheck);
    
    if (protectedPathCheck.status === 'failed') {
      hardBlock = true;
      hardBlockReason = 'CRITICAL: Attempted modification of protected System Zone paths.';
      severitySummary.critical++;
      blockers.push('CRITICAL: Protected System Zone paths have been modified. Use overrides/ instead.');
    }

    // 7. Lint-on-Synthesis Check (NEW - prevents App Zone importing System Zone)
    const lintCheck = await this.checkSystemZoneImports();
    checks.push(lintCheck);
    
    if (lintCheck.status === 'failed') {
      severitySummary.high++;
      blockers.push('App Zone code imports System Zone internals. Use public APIs or overrides/.');
    }

    // 8. Approval Checks
    const approvals = this.loadApprovals();

    if (this.config.requireTechLeadApproval) {
      const techLeadCheck: GateCheck = {
        name: 'Tech Lead Approval',
        status: approvals.techLead ? 'passed' : 'pending',
        required: true,
        message: approvals.techLead 
          ? `Approved by ${approvals.techLeadBy} on ${approvals.techLeadAt}`
          : 'Awaiting Tech Lead approval',
        severity: approvals.techLead ? 'info' : 'high',
      };
      checks.push(techLeadCheck);
      
      if (!approvals.techLead) {
        severitySummary.high++;
        blockers.push('Tech Lead approval required. Run `npm run gate:approve -- --tech-lead`.');
      }
    }

    if (this.config.requireSecurityApproval) {
      const securityCheck: GateCheck = {
        name: 'Security Auditor Approval',
        status: approvals.securityAuditor ? 'passed' : 'pending',
        required: true,
        message: approvals.securityAuditor
          ? `Approved by ${approvals.securityAuditorBy} on ${approvals.securityAuditorAt}`
          : 'Awaiting Security Auditor approval',
        details: approvals.securityAuditor ? {
          trufflehogClean: approvals.trufflehogClean,
          scanDate: approvals.securityScanAt,
        } : undefined,
        severity: approvals.securityAuditor ? 'info' : 'high',
      };
      checks.push(securityCheck);
      
      if (!approvals.securityAuditor) {
        severitySummary.high++;
        blockers.push('Security Auditor approval required. Run `npm run gate:approve -- --security`.');
      }
    }

    // Determine if deployment can proceed
    // Hard block takes precedence - cannot be overridden
    const canDeploy = !hardBlock && blockers.length === 0;

    return {
      canDeploy,
      checks,
      blockers,
      warnings,
      timestamp: new Date(),
      approvals: {
        techLead: approvals.techLead || false,
        securityAuditor: approvals.securityAuditor || false,
      },
      severitySummary,
      hardBlock,
      hardBlockReason,
    };
  }

  /**
   * Check for modifications to protected System Zone paths.
   */
  private async checkProtectedPaths(): Promise<GateCheck> {
    const protectedPaths = [
      '.claude/',
      'system/core/integrity.ts',
      'system/core/deployment-gate.ts',
      'system/core/framework.ts',
      'loa.yaml',
    ];

    try {
      // Check git status for modifications to protected paths
      const result = execSync('git status --porcelain', {
        cwd: this.rootDir,
        encoding: 'utf-8',
      });

      const modifiedFiles = result
        .split('\n')
        .filter(line => line.trim())
        .map(line => line.substring(3).trim());

      const protectedModifications = modifiedFiles.filter(file =>
        protectedPaths.some(p => file.startsWith(p))
      );

      if (protectedModifications.length > 0) {
        return {
          name: 'Protected Paths Check',
          status: 'failed',
          required: true,
          message: `${protectedModifications.length} protected file(s) modified`,
          details: { modifiedFiles: protectedModifications },
          severity: 'critical',
          executedAt: new Date(),
        };
      }

      return {
        name: 'Protected Paths Check',
        status: 'passed',
        required: true,
        message: 'No protected System Zone paths modified',
        severity: 'info',
        executedAt: new Date(),
      };
    } catch {
      return {
        name: 'Protected Paths Check',
        status: 'skipped',
        required: true,
        message: 'Not a git repository',
        severity: 'warning',
        executedAt: new Date(),
      };
    }
  }

  /**
   * Lint-on-Synthesis: Check that App Zone doesn't import System Zone private members.
   * Prevents "leakage" that would break future framework updates.
   */
  private async checkSystemZoneImports(): Promise<GateCheck> {
    const appZonePaths = ['app/', 'src/', 'packages/'];
    const systemZonePrivatePatterns = [
      /from ['"]\.\.\/\.\.\/system\/core\//,
      /from ['"]\.\.\/system\/core\//,
      /from ['"]system\/core\//,
      /from ['"]\.claude\//,
      /require\(['"].*system\/core/,
      /require\(['"].*\.claude/,
    ];

    const violations: string[] = [];

    try {
      // Find all TypeScript/JavaScript files in App Zone
      for (const appPath of appZonePaths) {
        const fullPath = path.join(this.rootDir, appPath);
        if (!fs.existsSync(fullPath)) continue;

        const files = this.findFilesRecursive(fullPath, ['.ts', '.tsx', '.js', '.jsx']);
        
        for (const file of files) {
          const content = fs.readFileSync(file, 'utf-8');
          
          for (const pattern of systemZonePrivatePatterns) {
            if (pattern.test(content)) {
              const relativePath = path.relative(this.rootDir, file);
              violations.push(relativePath);
              break; // One violation per file is enough
            }
          }
        }
      }

      if (violations.length > 0) {
        return {
          name: 'Lint-on-Synthesis',
          status: 'failed',
          required: true,
          message: `${violations.length} file(s) import System Zone internals`,
          details: { 
            violations: violations.slice(0, 10), // Limit output
            total: violations.length,
            hint: 'Use public APIs or overrides/ instead of importing System Zone directly',
          },
          severity: 'high',
          executedAt: new Date(),
        };
      }

      return {
        name: 'Lint-on-Synthesis',
        status: 'passed',
        required: true,
        message: 'No System Zone import violations',
        severity: 'info',
        executedAt: new Date(),
      };
    } catch (error) {
      return {
        name: 'Lint-on-Synthesis',
        status: 'skipped',
        required: false,
        message: `Check failed: ${(error as Error).message}`,
        severity: 'warning',
        executedAt: new Date(),
      };
    }
  }

  /**
   * Helper to find files recursively with given extensions.
   */
  private findFilesRecursive(dir: string, extensions: string[]): string[] {
    const files: string[] = [];
    
    try {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      
      for (const entry of entries) {
        const fullPath = path.join(dir, entry.name);
        
        // Skip node_modules and hidden directories
        if (entry.name.startsWith('.') || entry.name === 'node_modules') {
          continue;
        }
        
        if (entry.isDirectory()) {
          files.push(...this.findFilesRecursive(fullPath, extensions));
        } else if (entry.isFile()) {
          const ext = path.extname(entry.name);
          if (extensions.includes(ext)) {
            files.push(fullPath);
          }
        }
      }
    } catch {
      // Ignore permission errors
    }
    
    return files;
  }

  // ===========================================================================
  // INDIVIDUAL CHECKS
  // ===========================================================================

  /**
   * Check System Zone integrity.
   */
  private async checkSystemIntegrity(): Promise<GateCheck> {
    try {
      const verifier = new IntegrityVerifier(this.rootDir);
      const result: VerificationResult = await verifier.verify({ zone: 'system' });

      if (!result.success) {
        return {
          name: 'System Zone Integrity',
          status: 'failed',
          required: true,
          message: `${result.violations.length} integrity violation(s) detected`,
          details: {
            violations: result.violations.map(v => ({
              path: v.path,
              type: v.type,
              severity: v.severity,
            })),
          },
          executedAt: new Date(),
        };
      }

      return {
        name: 'System Zone Integrity',
        status: 'passed',
        required: true,
        message: `${result.filesChecked} files verified, no violations`,
        executedAt: new Date(),
      };
    } catch (error) {
      return {
        name: 'System Zone Integrity',
        status: 'failed',
        required: true,
        message: `Integrity check error: ${(error as Error).message}`,
        executedAt: new Date(),
      };
    }
  }

  /**
   * Scan for secrets using TruffleHog or Gitleaks.
   */
  private async checkForSecrets(): Promise<GateCheck> {
    for (const scanner of this.config.secretScanners) {
      try {
        if (scanner === 'trufflehog') {
          // TruffleHog filesystem scan
          const result = execSync(
            'trufflehog filesystem . --only-verified --json 2>/dev/null || true',
            { 
              cwd: this.rootDir,
              encoding: 'utf-8',
              maxBuffer: 10 * 1024 * 1024,
            }
          );

          // TruffleHog outputs JSON lines for each finding
          const findings = result
            .trim()
            .split('\n')
            .filter(line => line.length > 0)
            .map(line => {
              try {
                return JSON.parse(line);
              } catch {
                return null;
              }
            })
            .filter(Boolean);

          if (findings.length > 0) {
            return {
              name: 'Secrets Scan (TruffleHog)',
              status: 'failed',
              required: true,
              message: `${findings.length} secret(s) detected`,
              details: {
                scanner: 'trufflehog',
                findingsCount: findings.length,
                findings: findings.slice(0, 5).map(f => ({
                  detector: f.DetectorName,
                  file: f.SourceMetadata?.Data?.Filesystem?.file,
                })),
              },
              executedAt: new Date(),
            };
          }

          return {
            name: 'Secrets Scan (TruffleHog)',
            status: 'passed',
            required: true,
            message: 'TruffleHog Clean - No secrets detected',
            executedAt: new Date(),
          };
        }

        if (scanner === 'gitleaks') {
          // Gitleaks scan
          const result = execSync(
            'gitleaks detect --no-git --report-format json --report-path /dev/stdout 2>/dev/null || true',
            {
              cwd: this.rootDir,
              encoding: 'utf-8',
              maxBuffer: 10 * 1024 * 1024,
            }
          );

          try {
            const findings = JSON.parse(result);
            if (Array.isArray(findings) && findings.length > 0) {
              return {
                name: 'Secrets Scan (Gitleaks)',
                status: 'failed',
                required: true,
                message: `${findings.length} secret(s) detected`,
                details: {
                  scanner: 'gitleaks',
                  findingsCount: findings.length,
                },
                executedAt: new Date(),
              };
            }
          } catch {
            // Empty or invalid JSON means no findings
          }

          return {
            name: 'Secrets Scan (Gitleaks)',
            status: 'passed',
            required: true,
            message: 'Gitleaks Clean - No secrets detected',
            executedAt: new Date(),
          };
        }
      } catch (error) {
        // Scanner not installed or error running
        return {
          name: `Secrets Scan (${scanner})`,
          status: 'skipped',
          required: true,
          message: `${scanner} not available: ${(error as Error).message}`,
          executedAt: new Date(),
        };
      }
    }

    return {
      name: 'Secrets Scan',
      status: 'skipped',
      required: true,
      message: 'No secret scanners configured',
      executedAt: new Date(),
    };
  }

  /**
   * Check current git branch.
   */
  private checkBranch(): GateCheck {
    try {
      const branch = execSync('git rev-parse --abbrev-ref HEAD', {
        cwd: this.rootDir,
        encoding: 'utf-8',
      }).trim();

      const isAllowed = this.config.allowedBranches.some(pattern => {
        if (pattern.endsWith('/*')) {
          const prefix = pattern.slice(0, -1);
          return branch.startsWith(prefix);
        }
        return branch === pattern;
      });

      return {
        name: 'Branch Check',
        status: isAllowed ? 'passed' : 'failed',
        required: false,
        message: isAllowed 
          ? `Deploying from approved branch: ${branch}`
          : `Branch '${branch}' not in allowed list`,
        details: { branch, allowedBranches: this.config.allowedBranches },
        executedAt: new Date(),
      };
    } catch {
      return {
        name: 'Branch Check',
        status: 'skipped',
        required: false,
        message: 'Not a git repository',
        executedAt: new Date(),
      };
    }
  }

  /**
   * Check for dependency vulnerabilities.
   */
  private async checkDependencies(): Promise<GateCheck> {
    try {
      execSync('npm audit --audit-level=high --json', {
        cwd: this.rootDir,
        encoding: 'utf-8',
      });

      return {
        name: 'Dependency Vulnerabilities',
        status: 'passed',
        required: false,
        message: 'No high/critical vulnerabilities found',
        executedAt: new Date(),
      };
    } catch (error: any) {
      // npm audit exits with non-zero if vulnerabilities found
      try {
        const auditResult = JSON.parse(error.stdout || '{}');
        const vulnCount = auditResult.metadata?.vulnerabilities?.high || 0 +
                         auditResult.metadata?.vulnerabilities?.critical || 0;
        
        return {
          name: 'Dependency Vulnerabilities',
          status: vulnCount > 0 ? 'failed' : 'passed',
          required: false,
          message: vulnCount > 0 
            ? `${vulnCount} high/critical vulnerabilities found`
            : 'No high/critical vulnerabilities',
          details: auditResult.metadata?.vulnerabilities,
          executedAt: new Date(),
        };
      } catch {
        return {
          name: 'Dependency Vulnerabilities',
          status: 'skipped',
          required: false,
          message: 'Unable to run npm audit',
          executedAt: new Date(),
        };
      }
    }
  }

  // ===========================================================================
  // APPROVAL MANAGEMENT
  // ===========================================================================

  /**
   * Load approval state.
   */
  private loadApprovals(): Record<string, any> {
    try {
      if (fs.existsSync(this.approvalsFile)) {
        return JSON.parse(fs.readFileSync(this.approvalsFile, 'utf-8'));
      }
    } catch {}
    return {};
  }

  /**
   * Save approval state.
   */
  private saveApprovals(approvals: Record<string, any>): void {
    const dir = path.dirname(this.approvalsFile);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(this.approvalsFile, JSON.stringify(approvals, null, 2));
  }

  /**
   * Record Tech Lead approval.
   */
  approveTechLead(approver: string): void {
    const approvals = this.loadApprovals();
    approvals.techLead = true;
    approvals.techLeadBy = approver;
    approvals.techLeadAt = new Date().toISOString();
    this.saveApprovals(approvals);
    console.log(`✅ Tech Lead approval recorded by ${approver}`);
  }

  /**
   * Record Security Auditor approval.
   * Requires TruffleHog clean status.
   */
  async approveSecurityAuditor(approver: string): Promise<boolean> {
    // First verify TruffleHog is clean
    const secretsCheck = await this.checkForSecrets();
    
    if (secretsCheck.status !== 'passed') {
      console.error('❌ Cannot approve: TruffleHog scan not clean');
      console.error(`   Status: ${secretsCheck.message}`);
      return false;
    }

    const approvals = this.loadApprovals();
    approvals.securityAuditor = true;
    approvals.securityAuditorBy = approver;
    approvals.securityAuditorAt = new Date().toISOString();
    approvals.trufflehogClean = true;
    approvals.securityScanAt = new Date().toISOString();
    this.saveApprovals(approvals);
    
    console.log(`✅ Security Auditor approval recorded by ${approver}`);
    console.log(`   TruffleHog Clean: ✓`);
    return true;
  }

  /**
   * Reset all approvals (for new release cycle).
   */
  resetApprovals(): void {
    this.saveApprovals({});
    console.log('✅ All approvals reset');
  }

  // ===========================================================================
  // REPORTING
  // ===========================================================================

  /**
   * Generate deployment gate report.
   */
  formatReport(result: DeploymentGateResult): string {
    const lines: string[] = [
      '',
      '╔═══════════════════════════════════════════════════════════════════════════╗',
      '║                      DEPLOYMENT GATE REPORT                               ║',
      '╠═══════════════════════════════════════════════════════════════════════════╣',
      `║  Timestamp: ${result.timestamp.toISOString().padEnd(62)}║`,
      `║  Can Deploy: ${(result.canDeploy ? '✅ YES' : '❌ NO').padEnd(61)}║`,
    ];

    // Show hard block warning prominently
    if (result.hardBlock) {
      lines.push('╠═══════════════════════════════════════════════════════════════════════════╣');
      lines.push('║  🚨🚨🚨 HARD BLOCK ACTIVE - BUILD CANNOT PROCEED 🚨🚨🚨                    ║');
      const reason = (result.hardBlockReason || 'Unknown').slice(0, 70);
      lines.push(`║  Reason: ${reason.padEnd(64)}║`);
    }

    // Severity summary
    lines.push('╠═══════════════════════════════════════════════════════════════════════════╣');
    lines.push(`║  SEVERITY SUMMARY:  🔴 Critical: ${result.severitySummary.critical}  🟠 High: ${result.severitySummary.high}  🟡 Warning: ${result.severitySummary.warning}  🟢 Info: ${result.severitySummary.info}   ║`);

    lines.push('╠═══════════════════════════════════════════════════════════════════════════╣');
    lines.push('║  CHECKS:                                                                  ║');

    for (const check of result.checks) {
      const icon = check.status === 'passed' ? '✅' : 
                   check.status === 'failed' ? '❌' :
                   check.status === 'pending' ? '⏳' : '⏭️';
      const severityIcon = check.severity === 'critical' ? '🔴' :
                          check.severity === 'high' ? '🟠' :
                          check.severity === 'warning' ? '🟡' : '🟢';
      const required = check.required ? '[REQ]' : '[OPT]';
      lines.push(`║  ${icon} ${severityIcon} ${required} ${check.name.padEnd(17)} ${check.message.slice(0, 37).padEnd(37)}║`);
    }

    if (result.blockers.length > 0) {
      lines.push('╠═══════════════════════════════════════════════════════════════════════════╣');
      lines.push('║  🚫 BLOCKERS:                                                             ║');
      for (const blocker of result.blockers) {
        const wrapped = blocker.slice(0, 72);
        lines.push(`║    • ${wrapped.padEnd(68)}║`);
      }
    }

    if (result.warnings.length > 0) {
      lines.push('╠═══════════════════════════════════════════════════════════════════════════╣');
      lines.push('║  ⚠️  WARNINGS:                                                             ║');
      for (const warning of result.warnings) {
        const wrapped = warning.slice(0, 72);
        lines.push(`║    • ${wrapped.padEnd(68)}║`);
      }
    }

    lines.push('╠═══════════════════════════════════════════════════════════════════════════╣');
    lines.push(`║  Approvals: Tech Lead ${result.approvals.techLead ? '✅' : '❌'}  |  Security Auditor ${result.approvals.securityAuditor ? '✅' : '❌'}                    ║`);
    lines.push('╚═══════════════════════════════════════════════════════════════════════════╝');
    lines.push('');

    // Exit code guidance
    if (result.hardBlock) {
      lines.push('⛔ Hard block active. Fix critical issues before proceeding.');
      lines.push('   Run: npm run integrity:verify && npm run gate:check');
    }

    return lines.join('\n');
  }
}

// =============================================================================
// CLI INTERFACE
// =============================================================================

async function main() {
  const args = process.argv.slice(2);
  const command = args[0] || 'check';

  const gate = new DeploymentGateService();

  switch (command) {
    case 'check': {
      const result = await gate.runAllChecks();
      console.log(gate.formatReport(result));
      process.exit(result.canDeploy ? 0 : 1);
      break;
    }

    case 'approve': {
      const approver = args.find(a => a.startsWith('--by='))?.split('=')[1] || 'unknown';
      
      if (args.includes('--tech-lead')) {
        gate.approveTechLead(approver);
      } else if (args.includes('--security')) {
        await gate.approveSecurityAuditor(approver);
      } else {
        console.log('Specify --tech-lead or --security');
      }
      break;
    }

    case 'reset': {
      gate.resetApprovals();
      break;
    }

    default:
      console.log(`
Usage: npx ts-node system/core/deployment-gate.ts <command> [options]

Commands:
  check               Run all deployment gate checks
  approve             Record an approval
  reset               Reset all approvals

Options:
  --tech-lead         Approve as Tech Lead
  --security          Approve as Security Auditor
  --by=<name>         Approver name
      `);
  }
}

if (require.main === module) {
  main().catch(console.error);
}

export { DeploymentGateService, DeploymentGateResult, GateCheck };
