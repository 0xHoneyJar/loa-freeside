/**
 * Sietch Unified - Loa Framework Core
 * 
 * The Loa "mounts" and "rides" the host repository, providing:
 * - Three-Zone architecture management
 * - Configuration drift detection
 * - Atomic updates with rollback capability
 * - Secret management integration
 * 
 * Inspired by AWS Projen and Copier patterns.
 */

import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';
import YAML from 'yaml';
import { IntegrityVerifier } from './integrity';

// =============================================================================
// TYPES
// =============================================================================

interface LoaManifest {
  version: string;
  framework: string;
  schema_version: number;
  zones: ZoneConfig;
  integrity: IntegrityConfig;
  updates: UpdateConfig;
  anti_tamper: AntiTamperConfig;
  secrets: SecretsConfig;
}

interface ZoneConfig {
  system: {
    description: string;
    paths: string[];
    protected_files: Array<{ path: string; checksum_required: boolean }>;
  };
  state: {
    description: string;
    paths: string[];
    backup_on_update: string[];
  };
  app: {
    description: string;
    paths: string[];
  };
}

interface IntegrityConfig {
  enabled: boolean;
  algorithm: string;
  checksum_file: string;
  verification: {
    on_startup: boolean;
    on_build: boolean;
    scheduled: string;
  };
  on_failure: Array<{ action: string; severity?: string; destination?: string; channels?: string[] }>;
  exempt: string[];
}

interface UpdateConfig {
  pre_update: string[];
  post_update: string[];
  merge_strategy: Record<string, string>;
}

interface AntiTamperConfig {
  enabled: boolean;
  ci_validation: {
    enabled: boolean;
    fail_on_warning: boolean;
    fail_on_error: boolean;
  };
  git_hooks: {
    pre_commit: string[];
    pre_push: string[];
  };
}

interface SecretsConfig {
  providers: Array<{
    name: string;
    enabled: boolean;
    vault?: string;
    project?: string;
    path?: string;
  }>;
  mappings: Record<string, {
    provider: string;
    item?: string;
    field?: string;
    secret?: string;
  }>;
}

interface BackupManifest {
  timestamp: string;
  files: Array<{
    path: string;
    hash: string;
    size: number;
  }>;
  reason: string;
}

// =============================================================================
// LOA FRAMEWORK
// =============================================================================

export class LoaFramework {
  private rootDir: string;
  private manifest: LoaManifest;
  private integrityVerifier: IntegrityVerifier;

  constructor(rootDir: string = process.cwd()) {
    this.rootDir = rootDir;
    this.manifest = this.loadManifest();
    this.integrityVerifier = new IntegrityVerifier(rootDir);
  }

  // ---------------------------------------------------------------------------
  // MANIFEST MANAGEMENT
  // ---------------------------------------------------------------------------

  private loadManifest(): LoaManifest {
    const manifestPath = path.join(this.rootDir, 'loa.yaml');
    
    if (!fs.existsSync(manifestPath)) {
      throw new Error('loa.yaml not found. Initialize with `loa init`.');
    }
    
    const content = fs.readFileSync(manifestPath, 'utf-8');
    return YAML.parse(content) as LoaManifest;
  }

  // ---------------------------------------------------------------------------
  // ZONE MANAGEMENT
  // ---------------------------------------------------------------------------

  /**
   * Get the zone for a given file path
   */
  getZone(filePath: string): 'system' | 'state' | 'app' | 'unmanaged' {
    const normalizedPath = filePath.replace(/\\/g, '/');
    
    for (const pattern of this.manifest.zones.system.paths) {
      if (this.matchGlob(normalizedPath, pattern)) return 'system';
    }
    
    for (const pattern of this.manifest.zones.state.paths) {
      if (this.matchGlob(normalizedPath, pattern)) return 'state';
    }
    
    for (const pattern of this.manifest.zones.app.paths) {
      if (this.matchGlob(normalizedPath, pattern)) return 'app';
    }
    
    return 'unmanaged';
  }

  /**
   * Check if a file can be modified
   */
  canModify(filePath: string): { allowed: boolean; reason?: string } {
    const zone = this.getZone(filePath);
    
    if (zone === 'system') {
      const isProtected = this.manifest.zones.system.protected_files.some(
        pf => pf.path === filePath
      );
      
      if (isProtected) {
        return {
          allowed: false,
          reason: 'File is in protected system zone. Use official update mechanism.',
        };
      }
      
      return {
        allowed: false,
        reason: 'File is in system zone. Modifications will be overwritten on update.',
      };
    }
    
    if (zone === 'state') {
      return {
        allowed: true,
        reason: 'File is in state zone. Changes will be preserved across updates.',
      };
    }
    
    if (zone === 'app') {
      return {
        allowed: true,
        reason: 'File is in app zone. Full ownership.',
      };
    }
    
    return { allowed: true };
  }

  private matchGlob(filePath: string, pattern: string): boolean {
    const regexPattern = pattern
      .replace(/\*\*/g, '{{GLOBSTAR}}')
      .replace(/\*/g, '[^/]*')
      .replace(/{{GLOBSTAR}}/g, '.*')
      .replace(/\//g, '\\/');
    
    return new RegExp(`^${regexPattern}$`).test(filePath);
  }

  // ---------------------------------------------------------------------------
  // BACKUP OPERATIONS
  // ---------------------------------------------------------------------------

  /**
   * Create backup of state zone files before update
   */
  async createBackup(reason: string = 'pre-update'): Promise<string> {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupDir = path.join(this.rootDir, 'state', 'backups', timestamp);
    
    fs.mkdirSync(backupDir, { recursive: true });
    
    const manifest: BackupManifest = {
      timestamp,
      files: [],
      reason,
    };
    
    for (const pattern of this.manifest.zones.state.backup_on_update) {
      const filePath = path.join(this.rootDir, pattern);
      
      if (!fs.existsSync(filePath)) continue;
      
      const content = fs.readFileSync(filePath);
      const hash = crypto.createHash('sha256').update(content).digest('hex');
      const relativePath = path.relative(this.rootDir, filePath);
      
      // Copy file to backup
      const backupPath = path.join(backupDir, relativePath);
      fs.mkdirSync(path.dirname(backupPath), { recursive: true });
      fs.copyFileSync(filePath, backupPath);
      
      manifest.files.push({
        path: relativePath,
        hash,
        size: content.length,
      });
    }
    
    // Save manifest
    fs.writeFileSync(
      path.join(backupDir, 'manifest.json'),
      JSON.stringify(manifest, null, 2)
    );
    
    return backupDir;
  }

  /**
   * Restore from backup
   */
  async restoreBackup(backupDir: string): Promise<void> {
    const manifestPath = path.join(backupDir, 'manifest.json');
    
    if (!fs.existsSync(manifestPath)) {
      throw new Error('Backup manifest not found');
    }
    
    const manifest: BackupManifest = JSON.parse(
      fs.readFileSync(manifestPath, 'utf-8')
    );
    
    for (const file of manifest.files) {
      const sourcePath = path.join(backupDir, file.path);
      const destPath = path.join(this.rootDir, file.path);
      
      if (fs.existsSync(sourcePath)) {
        fs.mkdirSync(path.dirname(destPath), { recursive: true });
        fs.copyFileSync(sourcePath, destPath);
      }
    }
  }

  /**
   * List available backups
   */
  listBackups(): Array<{ timestamp: string; reason: string; fileCount: number }> {
    const backupsDir = path.join(this.rootDir, 'state', 'backups');
    
    if (!fs.existsSync(backupsDir)) return [];
    
    const backups: Array<{ timestamp: string; reason: string; fileCount: number }> = [];
    
    for (const dir of fs.readdirSync(backupsDir)) {
      const manifestPath = path.join(backupsDir, dir, 'manifest.json');
      
      if (fs.existsSync(manifestPath)) {
        const manifest: BackupManifest = JSON.parse(
          fs.readFileSync(manifestPath, 'utf-8')
        );
        
        backups.push({
          timestamp: manifest.timestamp,
          reason: manifest.reason,
          fileCount: manifest.files.length,
        });
      }
    }
    
    return backups.sort((a, b) => b.timestamp.localeCompare(a.timestamp));
  }

  // ---------------------------------------------------------------------------
  // UPDATE OPERATIONS
  // ---------------------------------------------------------------------------

  /**
   * Perform pre-update checks and backups
   */
  async prepareUpdate(): Promise<{ ready: boolean; backupDir?: string; errors: string[] }> {
    const errors: string[] = [];
    
    // Verify integrity first
    const integrityResult = await this.integrityVerifier.verify({ zone: 'all' });
    
    if (!integrityResult.success) {
      const criticalViolations = integrityResult.violations.filter(
        v => v.severity === 'critical'
      );
      
      if (criticalViolations.length > 0) {
        errors.push(`Critical integrity violations detected: ${criticalViolations.length}`);
        return { ready: false, errors };
      }
    }
    
    // Create backup
    let backupDir: string;
    try {
      backupDir = await this.createBackup('pre-update');
    } catch (err: any) {
      errors.push(`Backup failed: ${err.message}`);
      return { ready: false, errors };
    }
    
    return { ready: true, backupDir, errors };
  }

  /**
   * Finalize update (regenerate checksums)
   */
  async finalizeUpdate(): Promise<void> {
    // Regenerate checksums for system zone
    const manifest = await this.integrityVerifier.generateChecksums(['system']);
    this.integrityVerifier.saveManifest(manifest);
  }

  // ---------------------------------------------------------------------------
  // GRIMOIRE (STATE) MANAGEMENT
  // ---------------------------------------------------------------------------

  /**
   * Load grimoire (project state/memory)
   */
  loadGrimoire(): Record<string, any> {
    const grimoirePath = path.join(this.rootDir, 'state', 'grimoire.yaml');
    
    if (!fs.existsSync(grimoirePath)) {
      return {};
    }
    
    const content = fs.readFileSync(grimoirePath, 'utf-8');
    return YAML.parse(content) || {};
  }

  /**
   * Save grimoire
   */
  saveGrimoire(data: Record<string, any>): void {
    const grimoirePath = path.join(this.rootDir, 'state', 'grimoire.yaml');
    const dir = path.dirname(grimoirePath);
    
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    
    fs.writeFileSync(grimoirePath, YAML.stringify(data), 'utf-8');
  }

  /**
   * Update grimoire value
   */
  updateGrimoire(key: string, value: any): void {
    const grimoire = this.loadGrimoire();
    grimoire[key] = value;
    this.saveGrimoire(grimoire);
  }

  // ---------------------------------------------------------------------------
  // REPORTING
  // ---------------------------------------------------------------------------

  /**
   * Generate status report
   */
  async getStatus(): Promise<{
    framework: string;
    version: string;
    zones: {
      system: { fileCount: number; protected: number };
      state: { fileCount: number; backups: number };
      app: { fileCount: number };
    };
    integrity: { enabled: boolean; lastCheck?: string };
    secrets: { providers: string[] };
  }> {
    const integrityResult = await this.integrityVerifier.verify({ zone: 'all' });
    const backups = this.listBackups();
    
    return {
      framework: this.manifest.framework,
      version: this.manifest.version,
      zones: {
        system: {
          fileCount: Object.values(integrityResult).length,
          protected: this.manifest.zones.system.protected_files.length,
        },
        state: {
          fileCount: this.manifest.zones.state.backup_on_update.length,
          backups: backups.length,
        },
        app: {
          fileCount: 0, // Would need to count
        },
      },
      integrity: {
        enabled: this.manifest.integrity.enabled,
        lastCheck: integrityResult.timestamp,
      },
      secrets: {
        providers: this.manifest.secrets.providers
          .filter(p => p.enabled)
          .map(p => p.name),
      },
    };
  }
}

// =============================================================================
// CLI
// =============================================================================

async function main() {
  const args = process.argv.slice(2);
  const command = args[0] || 'status';
  
  const framework = new LoaFramework();
  
  switch (command) {
    case 'status': {
      const status = await framework.getStatus();
      console.log('╔═══════════════════════════════════════════════════════════╗');
      console.log('║              LOA FRAMEWORK STATUS                         ║');
      console.log('╠═══════════════════════════════════════════════════════════╣');
      console.log(`║  Framework: ${status.framework.padEnd(43)}║`);
      console.log(`║  Version: ${status.version.padEnd(45)}║`);
      console.log('╠═══════════════════════════════════════════════════════════╣');
      console.log('║  ZONES:                                                   ║');
      console.log(`║    System: ${status.zones.system.fileCount} files (${status.zones.system.protected} protected)`.padEnd(58) + '║');
      console.log(`║    State: ${status.zones.state.fileCount} tracked, ${status.zones.state.backups} backups`.padEnd(58) + '║');
      console.log('╠═══════════════════════════════════════════════════════════╣');
      console.log(`║  Integrity: ${status.integrity.enabled ? 'Enabled' : 'Disabled'}`.padEnd(58) + '║');
      console.log(`║  Secret Providers: ${status.secrets.providers.join(', ')}`.padEnd(58) + '║');
      console.log('╚═══════════════════════════════════════════════════════════╝');
      break;
    }
    
    case 'backup': {
      const reason = args[1] || 'manual';
      const backupDir = await framework.createBackup(reason);
      console.log(`✅ Backup created: ${backupDir}`);
      break;
    }
    
    case 'backups': {
      const backups = framework.listBackups();
      console.log('Available backups:');
      for (const backup of backups) {
        console.log(`  ${backup.timestamp} - ${backup.reason} (${backup.fileCount} files)`);
      }
      break;
    }
    
    case 'restore': {
      const backupDir = args[1];
      if (!backupDir) {
        console.error('Usage: loa restore <backup-dir>');
        process.exit(1);
      }
      await framework.restoreBackup(backupDir);
      console.log('✅ Backup restored');
      break;
    }
    
    case 'check': {
      const filePath = args[1];
      if (!filePath) {
        console.error('Usage: loa check <file-path>');
        process.exit(1);
      }
      const zone = framework.getZone(filePath);
      const canModify = framework.canModify(filePath);
      console.log(`File: ${filePath}`);
      console.log(`Zone: ${zone}`);
      console.log(`Can Modify: ${canModify.allowed ? 'Yes' : 'No'}`);
      if (canModify.reason) {
        console.log(`Reason: ${canModify.reason}`);
      }
      break;
    }
    
    default:
      console.log(`
Usage: npx ts-node system/core/framework.ts <command>

Commands:
  status    Show framework status
  backup    Create manual backup
  backups   List available backups
  restore   Restore from backup
  check     Check file zone and permissions
      `);
  }
}

if (require.main === module) {
  main().catch(console.error);
}

export { LoaFramework, LoaManifest };
