/**
 * Sietch Unified - Integrity Verification System
 * 
 * Implements AWS-style checksums and anti-tamper protection for the
 * managed scaffolding framework. Ensures system zone files haven't
 * been modified outside of official updates.
 * 
 * Part of the Loa Three-Zone Architecture:
 * - System Zone: Immutable framework code (this file lives here)
 * - State Zone: Project memory/grimoire
 * - App Zone: Developer-specific code
 */

import * as crypto from 'crypto';
import * as fs from 'fs';
import * as path from 'path';
import { glob } from 'glob';
import YAML from 'yaml';

// =============================================================================
// TYPES
// =============================================================================

interface ChecksumEntry {
  path: string;
  hash: string;
  algorithm: string;
  size: number;
  lastVerified: string;
  zone: 'system' | 'state' | 'app';
}

interface ChecksumManifest {
  version: string;
  generatedAt: string;
  algorithm: string;
  entries: Record<string, ChecksumEntry>;
}

interface IntegrityViolation {
  path: string;
  type: 'modified' | 'deleted' | 'added' | 'corrupted';
  expectedHash?: string;
  actualHash?: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  zone: string;
  timestamp: string;
}

interface LoaConfig {
  version: string;
  zones: {
    system: { paths: string[]; protected_files: Array<{ path: string; checksum_required: boolean }> };
    state: { paths: string[]; backup_on_update: string[] };
    app: { paths: string[] };
  };
  integrity: {
    enabled: boolean;
    algorithm: string;
    checksum_file: string;
    exempt: string[];
  };
}

interface VerificationResult {
  success: boolean;
  timestamp: string;
  filesChecked: number;
  violations: IntegrityViolation[];
  warnings: string[];
}

// =============================================================================
// INTEGRITY VERIFIER
// =============================================================================

export class IntegrityVerifier {
  private config: LoaConfig;
  private rootDir: string;
  private checksumFile: string;
  private algorithm: string;

  constructor(rootDir: string = process.cwd()) {
    this.rootDir = rootDir;
    this.config = this.loadConfig();
    this.algorithm = this.config.integrity.algorithm || 'sha256';
    this.checksumFile = path.join(rootDir, this.config.integrity.checksum_file);
  }

  // ---------------------------------------------------------------------------
  // CONFIGURATION
  // ---------------------------------------------------------------------------

  private loadConfig(): LoaConfig {
    const configPath = path.join(this.rootDir, 'loa.yaml');
    
    if (!fs.existsSync(configPath)) {
      throw new Error('loa.yaml not found. Is this a Loa-managed project?');
    }
    
    const content = fs.readFileSync(configPath, 'utf-8');
    return YAML.parse(content) as LoaConfig;
  }

  // ---------------------------------------------------------------------------
  // CHECKSUM OPERATIONS
  // ---------------------------------------------------------------------------

  /**
   * Calculate SHA-256 hash of a file
   */
  private calculateHash(filePath: string): string {
    const absolutePath = path.join(this.rootDir, filePath);
    const content = fs.readFileSync(absolutePath);
    return crypto.createHash(this.algorithm).update(content).digest('hex');
  }

  /**
   * Determine which zone a file belongs to
   */
  private getFileZone(filePath: string): 'system' | 'state' | 'app' | 'unknown' {
    const normalizedPath = filePath.replace(/\\/g, '/');
    
    for (const pattern of this.config.zones.system.paths) {
      if (this.matchPattern(normalizedPath, pattern)) return 'system';
    }
    
    for (const pattern of this.config.zones.state.paths) {
      if (this.matchPattern(normalizedPath, pattern)) return 'state';
    }
    
    for (const pattern of this.config.zones.app.paths) {
      if (this.matchPattern(normalizedPath, pattern)) return 'app';
    }
    
    return 'unknown';
  }

  /**
   * Simple glob pattern matching
   */
  private matchPattern(filePath: string, pattern: string): boolean {
    const regexPattern = pattern
      .replace(/\*\*/g, '{{GLOBSTAR}}')
      .replace(/\*/g, '[^/]*')
      .replace(/{{GLOBSTAR}}/g, '.*')
      .replace(/\//g, '\\/');
    
    return new RegExp(`^${regexPattern}$`).test(filePath);
  }

  /**
   * Check if file is exempt from integrity checks
   */
  private isExempt(filePath: string): boolean {
    const normalizedPath = filePath.replace(/\\/g, '/');
    
    for (const pattern of this.config.integrity.exempt) {
      if (this.matchPattern(normalizedPath, pattern)) return true;
    }
    
    return false;
  }

  // ---------------------------------------------------------------------------
  // MANIFEST OPERATIONS
  // ---------------------------------------------------------------------------

  /**
   * Load existing checksum manifest
   */
  loadManifest(): ChecksumManifest | null {
    if (!fs.existsSync(this.checksumFile)) {
      return null;
    }
    
    const content = fs.readFileSync(this.checksumFile, 'utf-8');
    return JSON.parse(content) as ChecksumManifest;
  }

  /**
   * Save checksum manifest
   */
  saveManifest(manifest: ChecksumManifest): void {
    const dir = path.dirname(this.checksumFile);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    
    fs.writeFileSync(
      this.checksumFile,
      JSON.stringify(manifest, null, 2),
      'utf-8'
    );
  }

  /**
   * Generate checksums for all tracked files
   */
  async generateChecksums(zones: ('system' | 'state' | 'app')[] = ['system']): Promise<ChecksumManifest> {
    const manifest: ChecksumManifest = {
      version: '1.0.0',
      generatedAt: new Date().toISOString(),
      algorithm: this.algorithm,
      entries: {},
    };

    const patterns: string[] = [];
    
    if (zones.includes('system')) {
      patterns.push(...this.config.zones.system.paths);
    }
    if (zones.includes('state')) {
      patterns.push(...this.config.zones.state.paths);
    }
    if (zones.includes('app')) {
      patterns.push(...this.config.zones.app.paths);
    }

    for (const pattern of patterns) {
      const files = await glob(pattern, {
        cwd: this.rootDir,
        nodir: true,
        ignore: ['**/node_modules/**', '**/dist/**', '**/.git/**'],
      });

      for (const file of files) {
        if (this.isExempt(file)) continue;
        
        const absolutePath = path.join(this.rootDir, file);
        if (!fs.existsSync(absolutePath)) continue;
        
        const stats = fs.statSync(absolutePath);
        const zone = this.getFileZone(file);
        
        manifest.entries[file] = {
          path: file,
          hash: this.calculateHash(file),
          algorithm: this.algorithm,
          size: stats.size,
          lastVerified: new Date().toISOString(),
          zone: zone as 'system' | 'state' | 'app',
        };
      }
    }

    return manifest;
  }

  // ---------------------------------------------------------------------------
  // VERIFICATION
  // ---------------------------------------------------------------------------

  /**
   * Verify integrity of all tracked files
   */
  async verify(options: {
    zone?: 'system' | 'state' | 'app' | 'all';
    failFast?: boolean;
  } = {}): Promise<VerificationResult> {
    const { zone = 'system', failFast = false } = options;
    
    const result: VerificationResult = {
      success: true,
      timestamp: new Date().toISOString(),
      filesChecked: 0,
      violations: [],
      warnings: [],
    };

    const manifest = this.loadManifest();
    
    if (!manifest) {
      result.warnings.push('No checksum manifest found. Run `npm run integrity:generate` first.');
      return result;
    }

    for (const [filePath, entry] of Object.entries(manifest.entries)) {
      // Filter by zone if specified
      if (zone !== 'all' && entry.zone !== zone) continue;
      
      result.filesChecked++;
      
      const absolutePath = path.join(this.rootDir, filePath);
      
      // Check if file exists
      if (!fs.existsSync(absolutePath)) {
        const violation: IntegrityViolation = {
          path: filePath,
          type: 'deleted',
          expectedHash: entry.hash,
          severity: entry.zone === 'system' ? 'critical' : 'medium',
          zone: entry.zone,
          timestamp: new Date().toISOString(),
        };
        
        result.violations.push(violation);
        result.success = false;
        
        if (failFast) break;
        continue;
      }
      
      // Verify hash
      const currentHash = this.calculateHash(filePath);
      
      if (currentHash !== entry.hash) {
        const severity = this.getViolationSeverity(filePath, entry.zone);
        
        const violation: IntegrityViolation = {
          path: filePath,
          type: 'modified',
          expectedHash: entry.hash,
          actualHash: currentHash,
          severity,
          zone: entry.zone,
          timestamp: new Date().toISOString(),
        };
        
        result.violations.push(violation);
        result.success = false;
        
        if (failFast) break;
      }
    }

    // Check for new files in system zone
    if (zone === 'system' || zone === 'all') {
      const currentSystemFiles = await glob(this.config.zones.system.paths.join(','), {
        cwd: this.rootDir,
        nodir: true,
        ignore: ['**/node_modules/**', '**/dist/**', '**/.git/**'],
      });
      
      for (const file of currentSystemFiles) {
        if (this.isExempt(file)) continue;
        if (!manifest.entries[file]) {
          result.violations.push({
            path: file,
            type: 'added',
            severity: 'high',
            zone: 'system',
            timestamp: new Date().toISOString(),
          });
          result.success = false;
        }
      }
    }

    return result;
  }

  /**
   * Determine severity based on file and zone
   */
  private getViolationSeverity(filePath: string, zone: string): 'low' | 'medium' | 'high' | 'critical' {
    // Check if file is in protected list
    const protectedFile = this.config.zones.system.protected_files.find(
      pf => pf.path === filePath
    );
    
    if (protectedFile?.checksum_required) {
      return 'critical';
    }
    
    if (zone === 'system') {
      return 'high';
    }
    
    if (zone === 'state') {
      return 'medium';
    }
    
    return 'low';
  }

  // ---------------------------------------------------------------------------
  // REPORTING
  // ---------------------------------------------------------------------------

  /**
   * Generate a human-readable report
   */
  formatReport(result: VerificationResult): string {
    const lines: string[] = [
      '╔═══════════════════════════════════════════════════════════╗',
      '║            INTEGRITY VERIFICATION REPORT                  ║',
      '╠═══════════════════════════════════════════════════════════╣',
      `║  Timestamp: ${result.timestamp.padEnd(43)}║`,
      `║  Files Checked: ${result.filesChecked.toString().padEnd(39)}║`,
      `║  Status: ${(result.success ? '✅ PASSED' : '❌ FAILED').padEnd(46)}║`,
      '╠═══════════════════════════════════════════════════════════╣',
    ];

    if (result.warnings.length > 0) {
      lines.push('║  WARNINGS:                                                ║');
      for (const warning of result.warnings) {
        lines.push(`║    ⚠️  ${warning.slice(0, 50).padEnd(50)}║`);
      }
      lines.push('╠═══════════════════════════════════════════════════════════╣');
    }

    if (result.violations.length > 0) {
      lines.push('║  VIOLATIONS:                                              ║');
      
      const bySeverity = {
        critical: result.violations.filter(v => v.severity === 'critical'),
        high: result.violations.filter(v => v.severity === 'high'),
        medium: result.violations.filter(v => v.severity === 'medium'),
        low: result.violations.filter(v => v.severity === 'low'),
      };
      
      for (const [severity, violations] of Object.entries(bySeverity)) {
        if (violations.length === 0) continue;
        
        const icon = severity === 'critical' ? '🚨' : severity === 'high' ? '❌' : severity === 'medium' ? '⚠️' : 'ℹ️';
        lines.push(`║                                                           ║`);
        lines.push(`║  ${icon} ${severity.toUpperCase()} (${violations.length}):`.padEnd(59) + '║');
        
        for (const v of violations.slice(0, 5)) {
          const shortPath = v.path.length > 45 ? '...' + v.path.slice(-42) : v.path;
          lines.push(`║    • ${shortPath.padEnd(51)}║`);
          lines.push(`║      Type: ${v.type.padEnd(45)}║`);
        }
        
        if (violations.length > 5) {
          lines.push(`║    ... and ${(violations.length - 5).toString()} more`.padEnd(59) + '║');
        }
      }
    } else {
      lines.push('║  No violations detected.                                  ║');
    }

    lines.push('╚═══════════════════════════════════════════════════════════╝');
    
    return lines.join('\n');
  }

  /**
   * Log violations to file
   */
  logViolations(result: VerificationResult): void {
    if (result.violations.length === 0) return;
    
    const logPath = path.join(this.rootDir, 'state', 'integrity-violations.log');
    const logDir = path.dirname(logPath);
    
    if (!fs.existsSync(logDir)) {
      fs.mkdirSync(logDir, { recursive: true });
    }
    
    const logEntry = {
      timestamp: result.timestamp,
      violations: result.violations,
    };
    
    const existingLog = fs.existsSync(logPath)
      ? fs.readFileSync(logPath, 'utf-8')
      : '';
    
    fs.writeFileSync(
      logPath,
      existingLog + JSON.stringify(logEntry) + '\n',
      'utf-8'
    );
  }
}

// =============================================================================
// CLI INTERFACE
// =============================================================================

async function main() {
  const args = process.argv.slice(2);
  const command = args[0] || 'verify';
  
  const verifier = new IntegrityVerifier();
  
  switch (command) {
    case 'generate': {
      console.log('Generating checksums...');
      const zones = args.includes('--all') 
        ? ['system', 'state', 'app'] as const
        : ['system'] as const;
      
      const manifest = await verifier.generateChecksums([...zones]);
      verifier.saveManifest(manifest);
      
      console.log(`✅ Generated checksums for ${Object.keys(manifest.entries).length} files`);
      console.log(`   Saved to: ${verifier['checksumFile']}`);
      break;
    }
    
    case 'verify': {
      const zone = args.includes('--all') ? 'all' : 
                   args.includes('--zone=state') ? 'state' :
                   args.includes('--zone=app') ? 'app' : 'system';
      
      const result = await verifier.verify({ zone: zone as any });
      console.log(verifier.formatReport(result));
      
      if (result.violations.length > 0) {
        verifier.logViolations(result);
      }
      
      process.exit(result.success ? 0 : 1);
      break;
    }
    
    case 'report': {
      const result = await verifier.verify({ zone: 'all' });
      console.log(verifier.formatReport(result));
      break;
    }
    
    default:
      console.log(`
Usage: npx ts-node system/core/integrity.ts <command> [options]

Commands:
  generate    Generate checksums for tracked files
  verify      Verify integrity of tracked files
  report      Generate full integrity report

Options:
  --all           Include all zones (system, state, app)
  --zone=<zone>   Verify specific zone (system, state, app)
  --fail-fast     Stop on first violation
      `);
  }
}

// Run if executed directly
if (require.main === module) {
  main().catch(console.error);
}

export { IntegrityVerifier, ChecksumManifest, IntegrityViolation, VerificationResult };
