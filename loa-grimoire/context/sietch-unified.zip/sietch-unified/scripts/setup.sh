#!/bin/bash

# =============================================================================
# SIETCH UNIFIED - SETUP SCRIPT
# =============================================================================
# This script helps you set up the Sietch Unified development environment.
# Run this from the project root directory.

set -e

echo "╔═══════════════════════════════════════════════════════════╗"
echo "║              SIETCH UNIFIED - SETUP WIZARD                ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check prerequisites
check_prerequisite() {
    if command -v $1 &> /dev/null; then
        echo -e "${GREEN}✓${NC} $1 is installed"
        return 0
    else
        echo -e "${RED}✗${NC} $1 is NOT installed"
        return 1
    fi
}

echo "🔍 Checking prerequisites..."
echo ""

MISSING_PREREQS=0

check_prerequisite "node" || MISSING_PREREQS=1
check_prerequisite "pnpm" || MISSING_PREREQS=1
check_prerequisite "docker" || MISSING_PREREQS=1
check_prerequisite "docker-compose" || echo -e "${YELLOW}!${NC} docker-compose not found (might be integrated into docker)"

echo ""

if [ $MISSING_PREREQS -eq 1 ]; then
    echo -e "${RED}Please install the missing prerequisites before continuing.${NC}"
    echo ""
    echo "Installation guides:"
    echo "  - Node.js: https://nodejs.org (v20+)"
    echo "  - pnpm: npm install -g pnpm"
    echo "  - Docker: https://docs.docker.com/get-docker/"
    exit 1
fi

# Check Node version
NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 20 ]; then
    echo -e "${RED}Node.js version 20 or higher is required. Current: $(node -v)${NC}"
    exit 1
fi
echo -e "${GREEN}✓${NC} Node.js version is compatible ($(node -v))"

echo ""
echo "📦 Installing dependencies..."
pnpm install

echo ""
echo "🔧 Setting up environment..."

if [ ! -f .env ]; then
    cp .env.example .env
    echo -e "${GREEN}✓${NC} Created .env file from .env.example"
    echo -e "${YELLOW}!${NC} Please edit .env with your actual credentials"
else
    echo -e "${YELLOW}!${NC} .env file already exists, skipping copy"
fi

echo ""
echo "🐳 Starting Docker services..."

# Start only core services (postgres and redis)
docker compose up -d postgres redis

echo ""
echo "⏳ Waiting for database to be ready..."
sleep 5

# Check if postgres is ready
until docker compose exec -T postgres pg_isready -U sietch -d sietch_unified > /dev/null 2>&1; do
    echo "  Waiting for PostgreSQL..."
    sleep 2
done
echo -e "${GREEN}✓${NC} PostgreSQL is ready"

# Check if Redis is ready
until docker compose exec -T redis redis-cli ping > /dev/null 2>&1; do
    echo "  Waiting for Redis..."
    sleep 2
done
echo -e "${GREEN}✓${NC} Redis is ready"

echo ""
echo "🗃️ Running database migrations..."
pnpm db:generate
pnpm db:push

echo ""
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║                  SETUP COMPLETE! 🎉                       ║"
echo "╠═══════════════════════════════════════════════════════════╣"
echo "║                                                           ║"
echo "║  Next steps:                                              ║"
echo "║                                                           ║"
echo "║  1. Edit .env with your API keys:                         ║"
echo "║     - COLLABLAND_API_KEY                                  ║"
echo "║     - DUNE_API_KEY                                        ║"
echo "║     - DISCORD_BOT_TOKEN                                   ║"
echo "║     - TELEGRAM_BOT_TOKEN                                  ║"
echo "║                                                           ║"
echo "║  2. Start development servers:                            ║"
echo "║     pnpm dev                                              ║"
echo "║                                                           ║"
echo "║  3. Or run individual services:                           ║"
echo "║     pnpm --filter @sietch/server dev                      ║"
echo "║     pnpm --filter @sietch/discord-bot dev                 ║"
echo "║     pnpm --filter @sietch/telegram-bot dev                ║"
echo "║     pnpm --filter @sietch/telegram-miniapp dev            ║"
echo "║                                                           ║"
echo "║  4. View database with Prisma Studio:                     ║"
echo "║     pnpm db:studio                                        ║"
echo "║                                                           ║"
echo "║  Useful commands:                                         ║"
echo "║     pnpm build        - Build all packages                ║"
echo "║     pnpm typecheck    - Type check all packages           ║"
echo "║     pnpm clean        - Clean all build artifacts         ║"
echo "║                                                           ║"
echo "╚═══════════════════════════════════════════════════════════╝"
